// src/services/notificationService.js
//
// A lightweight, in-app "alerts" feed — not a push-notification system.
// It watches live bus state (as fed by mockBusService) and raises simple
// local messages such as "Bus 204 is arriving" or "Bus 108 has been
// delayed". Screens can subscribe to read the running feed.

let alerts = [];
let listeners = new Set();
const seenStops = new Map(); // busId -> last currentStopIndex we alerted on
const seenStatus = new Map(); // busId -> last status we alerted on

function push(alert) {
  alerts = [{ id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, timestamp: Date.now(), ...alert }, ...alerts].slice(0, 30);
  listeners.forEach((l) => l(alerts));
}

/** Feed a fresh bus view through the alert engine (call on every tick). */
export function evaluateBus(busView) {
  const { id, number, status, nextStop, etaMinutes, currentStopIndex } = busView;

  const lastStatus = seenStatus.get(id);
  if (status !== lastStatus) {
    seenStatus.set(id, status);
    if (status === "Delayed") {
      push({
        busId: id,
        type: "warning",
        message: `Bus ${number} has been delayed.`,
      });
    }
    if (status === "Arriving") {
      push({
        busId: id,
        type: "info",
        message: `Bus ${number} is arriving at ${nextStop}.`,
      });
    }
  }

  if (status === "Moving" && etaMinutes <= 5 && etaMinutes > 4.3) {
    push({
      busId: id,
      type: "info",
      message: `Bus ${number} is about ${Math.round(etaMinutes)} min away from ${nextStop}.`,
    });
  }

  const lastStop = seenStops.get(id);
  if (lastStop !== currentStopIndex) {
    seenStops.set(id, currentStopIndex);
  }
}

export function getAlerts() {
  return alerts;
}

export function subscribeToAlerts(listener) {
  listeners.add(listener);
  listener(alerts);
  return () => listeners.delete(listener);
}

export function clearAlerts() {
  alerts = [];
  listeners.forEach((l) => l(alerts));
}

export default { evaluateBus, getAlerts, subscribeToAlerts, clearAlerts };
