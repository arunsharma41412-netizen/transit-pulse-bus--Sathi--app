// src/services/gpsSimulationEngine.js
//
// This is the heart of the "fake but believable" real-time tracking system.
//
// Real GPS hardware reports raw lat/lng + speed on an interval. Since we
// have no real transponders, this engine reproduces that behaviour: it
// owns a tick loop, advances each bus's position along its route polyline
// based on a simulated speed, derives current/next stop, ETA, status and
// seat counts from that position, and stamps everything with the time of
// the update. Anything that reads bus state (screens, mockBusService)
// only ever sees the *output* of this engine — never route math directly —
// which is what makes it possible to swap this whole file for a real GPS
// feed later without touching UI code (see mockBusService.js).

import { ROUTES, getRouteById } from "../data/routes";
import { BUSES } from "../data/buses";
import { distanceMeters, polylineLength, pointAtDistance } from "../utils/geo";

const TICK_MS = 3000; // realistic "GPS ping" interval for a demo app
const DWELL_TICKS_AT_STOP = 2; // how many ticks a bus pauses at a terminus
const MIN_SPEED_KMH = 14;
const MAX_SPEED_KMH = 42;
const DELAY_CHANCE_PER_TICK = 0.015; // small chance a moving bus becomes "Delayed"
const RECOVER_CHANCE_PER_TICK = 0.35; // chance a delayed bus recovers on a given tick

function computeRouteMeta(route) {
  const points = route.stops.map((s) => ({
    latitude: s.latitude,
    longitude: s.longitude,
  }));
  const cumulative = [0];
  for (let i = 1; i < points.length; i++) {
    cumulative.push(cumulative[i - 1] + distanceMeters(points[i - 1], points[i]));
  }
  return { points, cumulative, totalLength: cumulative[cumulative.length - 1] };
}

// Precompute route geometry once — this never changes at runtime.
const ROUTE_META = ROUTES.reduce((acc, route) => {
  acc[route.id] = computeRouteMeta(route);
  return acc;
}, {});

function stopIndicesForProgress(meta, progressM, direction) {
  const { cumulative } = meta;
  let idx = 0;
  for (let i = 0; i < cumulative.length - 1; i++) {
    if (progressM >= cumulative[i] && progressM <= cumulative[i + 1]) {
      idx = i;
      break;
    }
    if (progressM > cumulative[cumulative.length - 1]) idx = cumulative.length - 2;
  }
  if (direction >= 0) {
    return { currentStopIndex: idx, nextStopIndex: Math.min(idx + 1, cumulative.length - 1) };
  }
  return { currentStopIndex: idx + 1 <= cumulative.length - 1 ? idx + 1 : idx, nextStopIndex: idx };
}

function randomBetween(min, max) {
  return min + Math.random() * (max - min);
}

function initialSeatState(totalSeats) {
  // A freshly-seeded bus is mid-journey, so start it partially occupied
  // rather than empty or completely full.
  const occupied = Math.round(totalSeats * randomBetween(0.35, 0.75));
  return Math.max(totalSeats - occupied, 0);
}

class GpsSimulationEngine {
  constructor() {
    this.state = new Map(); // busId -> live state object
    this.listeners = new Set();
    this.timer = null;
    this._seed();
  }

  _seed() {
    BUSES.forEach((bus) => {
      const route = getRouteById(bus.routeId);
      const meta = ROUTE_META[bus.routeId];
      const progressM = meta.totalLength * bus.startProgressRatio;
      const { currentStopIndex, nextStopIndex } = stopIndicesForProgress(
        meta,
        progressM,
        bus.direction
      );
      const speedKmh = randomBetween(MIN_SPEED_KMH + 6, MAX_SPEED_KMH - 4);

      this.state.set(bus.id, {
        busId: bus.id,
        busNumber: bus.number,
        routeId: bus.routeId,
        totalSeats: bus.totalSeats,
        direction: bus.direction,
        progressM,
        speedKmh,
        latitude: meta.points[0].latitude,
        longitude: meta.points[0].longitude,
        bearing: 0,
        currentStopIndex,
        nextStopIndex,
        seatsAvailable: initialSeatState(bus.totalSeats),
        status: "Moving",
        dwellTicksRemaining: 0,
        distanceTravelledM: progressM,
        lastUpdated: Date.now(),
        etaMinutesToNextStop: 0,
      });
    });
    this._recomputeDerived(); // populate lat/lng/eta correctly on first pass
  }

  _recomputeDerived() {
    this.state.forEach((s, busId) => {
      const meta = ROUTE_META[s.routeId];
      const result = pointAtDistance(meta.points, s.progressM);
      if (!result) return;
      s.latitude = result.position.latitude;
      s.longitude = result.position.longitude;
      s.bearing = s.direction >= 0 ? result.bearing : (result.bearing + 180) % 360;

      const { currentStopIndex, nextStopIndex } = stopIndicesForProgress(
        meta,
        s.progressM,
        s.direction
      );
      s.currentStopIndex = currentStopIndex;
      s.nextStopIndex = nextStopIndex;

      const nextStopDistanceM = meta.cumulative[nextStopIndex];
      const remainingToNextStop = Math.abs(nextStopDistanceM - s.progressM);
      const speedMs = Math.max(s.speedKmh, 6) * (1000 / 3600);
      s.etaMinutesToNextStop = remainingToNextStop / speedMs / 60;
    });
  }

  _tickOnce() {
    this.state.forEach((s) => {
      const meta = ROUTE_META[s.routeId];

      // Handle a bus currently dwelling at a terminus.
      if (s.dwellTicksRemaining > 0) {
        s.dwellTicksRemaining -= 1;
        s.speedKmh = 0;
        s.status = "At Stop";
        if (s.dwellTicksRemaining === 0) {
          s.direction = s.direction >= 0 ? -1 : 1; // reverse the working
          s.status = "Moving";
        }
        s.lastUpdated = Date.now();
        return;
      }

      // Random delay / recovery simulation for realism.
      if (s.status === "Delayed") {
        if (Math.random() < RECOVER_CHANCE_PER_TICK) {
          s.status = "Moving";
        }
      } else if (Math.random() < DELAY_CHANCE_PER_TICK) {
        s.status = "Delayed";
      }

      const speedFactor = s.status === "Delayed" ? randomBetween(0.25, 0.5) : randomBetween(0.85, 1.1);
      s.speedKmh = clampSpeed(randomBetween(MIN_SPEED_KMH, MAX_SPEED_KMH) * speedFactor);

      const speedMs = s.speedKmh * (1000 / 3600);
      const deltaM = speedMs * (TICK_MS / 1000);

      const before = s.progressM;
      s.progressM += s.direction >= 0 ? deltaM : -deltaM;

      // Reached the far end of the route -> dwell, then reverse.
      if (s.progressM >= meta.totalLength) {
        s.progressM = meta.totalLength;
        s.status = "Completed";
        s.dwellTicksRemaining = DWELL_TICKS_AT_STOP;
      } else if (s.progressM <= 0) {
        s.progressM = 0;
        s.status = "Completed";
        s.dwellTicksRemaining = DWELL_TICKS_AT_STOP;
      } else {
        // Passing a stop: simulate boarding/alighting and briefly show "Arriving".
        const passedStopBoundary = didCrossAnyStop(meta, before, s.progressM);
        if (passedStopBoundary) {
          s.seatsAvailable = simulateBoarding(s.seatsAvailable, s.totalSeats);
        }
        const nearStop = distanceToNearestStop(meta, s.progressM) < 250;
        if (s.status !== "Delayed") {
          s.status = nearStop ? "Arriving" : "Moving";
        }
      }

      s.distanceTravelledM = s.direction >= 0 ? s.progressM : meta.totalLength - s.progressM;
      s.lastUpdated = Date.now();
    });

    this._recomputeDerived();
    this._notify();
  }

  start() {
    if (this.timer) return;
    this.timer = setInterval(() => this._tickOnce(), TICK_MS);
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  subscribe(listener) {
    this.listeners.add(listener);
    listener(this.getSnapshot());
    return () => this.listeners.delete(listener);
  }

  _notify() {
    const snapshot = this.getSnapshot();
    this.listeners.forEach((l) => l(snapshot));
  }

  getSnapshot() {
    return Array.from(this.state.values()).map((s) => ({ ...s }));
  }

  getBusState(busId) {
    const s = this.state.get(busId);
    return s ? { ...s } : null;
  }

  getRouteMeta(routeId) {
    return ROUTE_META[routeId];
  }
}

function clampSpeed(v) {
  return Math.min(Math.max(v, MIN_SPEED_KMH), MAX_SPEED_KMH);
}

function distanceToNearestStop(meta, progressM) {
  let min = Infinity;
  meta.cumulative.forEach((c) => {
    min = Math.min(min, Math.abs(c - progressM));
  });
  return min;
}

function didCrossAnyStop(meta, before, after) {
  const lo = Math.min(before, after);
  const hi = Math.max(before, after);
  return meta.cumulative.some((c) => c > lo && c <= hi);
}

function simulateBoarding(seatsAvailable, totalSeats) {
  const occupied = totalSeats - seatsAvailable;
  const alighting = Math.round(occupied * randomBetween(0.1, 0.35));
  const afterAlight = occupied - alighting;
  const freeSeats = totalSeats - afterAlight;
  const boarding = Math.round(freeSeats * randomBetween(0.15, 0.5));
  const finalOccupied = Math.min(afterAlight + boarding, totalSeats);
  return Math.max(totalSeats - finalOccupied, 0);
}

// Singleton — one simulation engine backs the whole app, exactly as a
// real device would have one GPS receiver feed shared across screens.
const gpsSimulationEngine = new GpsSimulationEngine();

export default gpsSimulationEngine;
export { TICK_MS };
