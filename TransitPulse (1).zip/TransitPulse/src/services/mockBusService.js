// src/services/mockBusService.js
//
// This module is the ONLY place the rest of the app talks to for bus/route
// data. It currently reads from the local GPS simulation engine, but every
// function returns plain, promise-based, JSON-shaped data — exactly what a
// real backend (e.g. a bus operator's live GPS/telemetry API) would return.
//
// To go live later: create `realBusService.js` that implements the same
// function signatures (backed by fetch/WebSocket calls to a real API) and
// swap the import wherever `mockBusService` is used. No screen or
// component needs to change.

import { ROUTES, getRouteById } from "../data/routes";
import { getBusesForRoute as getStaticBusesForRoute, getBusById as getStaticBusById } from "../data/buses";
import gpsSimulationEngine from "./gpsSimulationEngine";
import { formatDistance } from "../utils/formatters";

const NETWORK_DELAY_MS = 350; // simulated latency, so loading states are visible

function delay(ms = NETWORK_DELAY_MS) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function mergeBusView(staticBus, liveState, route) {
  if (!liveState) return null;
  const stops = route.stops;
  return {
    id: staticBus.id,
    number: staticBus.number,
    routeId: staticBus.routeId,
    routeName: route.name,
    routeNumber: route.number,
    fare: route.fare,
    baseFare: route.baseFare,
    distanceKm: route.distanceKm,
    totalSeats: liveState.totalSeats,
    seatsAvailable: liveState.seatsAvailable,
    seatsOccupied: liveState.totalSeats - liveState.seatsAvailable,
    latitude: liveState.latitude,
    longitude: liveState.longitude,
    bearing: liveState.bearing,
    speedKmh: liveState.speedKmh,
    status: liveState.status,
    currentStop: stops[liveState.currentStopIndex]?.name || "—",
    nextStop: stops[liveState.nextStopIndex]?.name || "—",
    currentStopIndex: liveState.currentStopIndex,
    nextStopIndex: liveState.nextStopIndex,
    etaMinutes: liveState.etaMinutesToNextStop,
    distanceTravelled: formatDistance(liveState.distanceTravelledM),
    distanceTravelledM: liveState.distanceTravelledM,
    lastUpdated: liveState.lastUpdated,
    destination: route.stops[route.stops.length - 1].name,
    origin: route.stops[0].name,
  };
}

/** Returns the full route catalogue (route + stop + fare metadata). */
export async function getRoutes() {
  await delay();
  return ROUTES.map((r) => ({
    id: r.id,
    name: r.name,
    number: r.number,
    fare: r.fare,
    baseFare: r.baseFare,
    distanceKm: r.distanceKm,
    estimatedMinutes: r.estimatedMinutes,
    stopCount: r.stops.length,
    origin: r.stops[0].name,
    destination: r.stops[r.stops.length - 1].name,
    busCount: getStaticBusesForRoute(r.id).length,
  }));
}

/** Returns full route detail including ordered stops. */
export async function getRouteDetail(routeId) {
  await delay();
  return getRouteById(routeId);
}

/**
 * Search routes by source, destination, route number, or bus number.
 * A simple, forgiving substring match — enough to power the search screen.
 */
export async function searchRoutes(query) {
  await delay(250);
  const q = (query || "").trim().toLowerCase();
  if (!q) return [];

  const routeMatches = ROUTES.filter((r) => {
    const haystack = [
      r.name,
      r.number,
      ...r.stops.map((s) => s.name),
    ]
      .join(" ")
      .toLowerCase();
    return haystack.includes(q);
  });

  const busMatches = ROUTES.filter((r) =>
    getStaticBusesForRoute(r.id).some((b) => b.number.toLowerCase().includes(q))
  );

  const merged = [...routeMatches];
  busMatches.forEach((r) => {
    if (!merged.find((m) => m.id === r.id)) merged.push(r);
  });

  return merged.map((r) => ({
    id: r.id,
    name: r.name,
    number: r.number,
    fare: r.fare,
    distanceKm: r.distanceKm,
    estimatedMinutes: r.estimatedMinutes,
    origin: r.stops[0].name,
    destination: r.stops[r.stops.length - 1].name,
    busCount: getStaticBusesForRoute(r.id).length,
  }));
}

/** Returns all buses currently operating on a route, with live GPS state merged in. */
export async function getBusesForRoute(routeId) {
  await delay();
  const route = getRouteById(routeId);
  if (!route) return [];
  const staticBuses = getStaticBusesForRoute(routeId);
  return staticBuses
    .map((b) => mergeBusView(b, gpsSimulationEngine.getBusState(b.id), route))
    .filter(Boolean);
}

/** Returns one bus's full live detail view. */
export async function getBusDetail(busId) {
  await delay();
  const staticBus = getStaticBusById(busId);
  if (!staticBus) return null;
  const route = getRouteById(staticBus.routeId);
  return mergeBusView(staticBus, gpsSimulationEngine.getBusState(busId), route);
}

/**
 * Subscribe to live updates for every bus on a route. Calls `onUpdate`
 * with a fresh array of bus views every simulation tick. Returns an
 * unsubscribe function — always call it on unmount.
 */
export function subscribeToRoute(routeId, onUpdate) {
  const route = getRouteById(routeId);
  if (!route) return () => {};
  const staticBuses = getStaticBusesForRoute(routeId);

  return gpsSimulationEngine.subscribe((allBusStates) => {
    const byId = new Map(allBusStates.map((s) => [s.busId, s]));
    const views = staticBuses
      .map((b) => mergeBusView(b, byId.get(b.id), route))
      .filter(Boolean);
    onUpdate(views);
  });
}

/** Subscribe to live updates for a single bus. */
export function subscribeToBus(busId, onUpdate) {
  const staticBus = getStaticBusById(busId);
  if (!staticBus) return () => {};
  const route = getRouteById(staticBus.routeId);

  return gpsSimulationEngine.subscribe((allBusStates) => {
    const liveState = allBusStates.find((s) => s.busId === busId);
    const view = mergeBusView(staticBus, liveState, route);
    if (view) onUpdate(view);
  });
}

/** Ensures the simulation is running — call once near app startup. */
export function startLiveTracking() {
  gpsSimulationEngine.start();
}

export function stopLiveTracking() {
  gpsSimulationEngine.stop();
}

export default {
  getRoutes,
  getRouteDetail,
  searchRoutes,
  getBusesForRoute,
  getBusDetail,
  subscribeToRoute,
  subscribeToBus,
  startLiveTracking,
  stopLiveTracking,
};
