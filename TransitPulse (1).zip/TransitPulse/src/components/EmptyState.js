// src/components/EmptyState.js
import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing, typography } from "../constants/theme";

/**
 * A single, reusable component for empty / error / unavailable states,
 * so every "nothing to show" moment in the app still looks intentional
 * and on-brand instead of a bare blank screen.
 */
export default function EmptyState({
  icon = "search-outline",
  title = "Nothing here yet",
  message,
  actionLabel,
  onAction,
  tone = "neutral", // "neutral" | "error"
}) {
  const iconColor = tone === "error" ? colors.danger : colors.textTertiary;
  const iconBg = tone === "error" ? colors.dangerSoft : colors.surfaceAlt;

  return (
    <View style={styles.container}>
      <View style={[styles.iconCircle, { backgroundColor: iconBg }]}>
        <Ionicons name={icon} size={30} color={iconColor} />
      </View>
      <Text style={styles.title}>{title}</Text>
      {message ? <Text style={styles.message}>{message}</Text> : null}
      {actionLabel && onAction ? (
        <TouchableOpacity style={styles.actionButton} onPress={onAction}>
          <Text style={styles.actionText}>{actionLabel}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: spacing.xxxl,
    paddingHorizontal: spacing.xl,
  },
  iconCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.lg,
  },
  title: {
    ...typography.h3,
    color: colors.textPrimary,
    textAlign: "center",
    marginBottom: spacing.xs,
  },
  message: {
    ...typography.body,
    color: colors.textSecondary,
    textAlign: "center",
    lineHeight: 20,
  },
  actionButton: {
    marginTop: spacing.lg,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.md - 2,
    backgroundColor: colors.primarySoft,
    borderRadius: radius.md,
  },
  actionText: {
    ...typography.bodyStrong,
    color: colors.primary,
  },
});
