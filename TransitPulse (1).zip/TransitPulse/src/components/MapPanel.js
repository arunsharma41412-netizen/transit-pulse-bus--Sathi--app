// src/components/MapPanel.js
import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing, typography, shadow } from "../constants/theme";
import StatusBadge from "./StatusBadge";
import ETADisplay from "./ETADisplay";
import SeatAvailability from "./SeatAvailability";
import { formatSpeed, formatFare } from "../utils/formatters";

export default function MapPanel({ bus, onExpand, expanded, onCollapse }) {
  if (!bus) return null;

  return (
    <View style={[styles.panel, expanded && styles.panelExpanded]}>
      <TouchableOpacity style={styles.handleArea} onPress={expanded ? onCollapse : onExpand} activeOpacity={0.7}>
        <View style={styles.handle} />
      </TouchableOpacity>

      <View style={styles.headerRow}>
        <View>
          <Text style={styles.busNumber}>BUS {bus.number.split(" ").pop()}</Text>
          <Text style={styles.routeName} numberOfLines={1}>{bus.routeName}</Text>
        </View>
        <StatusBadge status={bus.status} />
      </View>

      <View style={styles.etaRow}>
        <View>
          <Text style={styles.nextStopLabel}>NEXT STOP</Text>
          <Text style={styles.nextStopValue}>{bus.nextStop}</Text>
        </View>
        <ETADisplay etaMinutes={bus.etaMinutes} lastUpdated={bus.lastUpdated} size="lg" />
      </View>

      <View style={styles.quickStatsRow}>
        <View style={styles.quickStat}>
          <Ionicons name="speedometer-outline" size={16} color={colors.textSecondary} />
          <Text style={styles.quickStatText}>{formatSpeed(bus.speedKmh)}</Text>
        </View>
        <View style={styles.quickStat}>
          <Ionicons name="people-outline" size={16} color={colors.textSecondary} />
          <Text style={styles.quickStatText}>{bus.seatsAvailable} seats</Text>
        </View>
        <View style={styles.quickStat}>
          <Ionicons name="pricetag-outline" size={16} color={colors.textSecondary} />
          <Text style={styles.quickStatText}>{formatFare(bus.fare)}</Text>
        </View>
      </View>

      {expanded && (
        <View style={styles.expandedSection}>
          <View style={styles.divider} />
          <SeatAvailability available={bus.seatsAvailable} total={bus.totalSeats} />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  panel: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.xl,
    paddingTop: spacing.sm,
    ...Platform.select({ ios: shadow.floating, android: { elevation: 8 } }),
  },
  panelExpanded: {
    paddingBottom: spacing.xxl,
  },
  handleArea: {
    alignItems: "center",
    paddingVertical: spacing.sm,
  },
  handle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.borderStrong,
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: spacing.md,
  },
  busNumber: {
    ...typography.h3,
    color: colors.textPrimary,
  },
  routeName: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: 2,
    maxWidth: 220,
  },
  etaRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginBottom: spacing.lg,
  },
  nextStopLabel: {
    ...typography.micro,
    color: colors.textTertiary,
    letterSpacing: 0.4,
    marginBottom: 2,
  },
  nextStopValue: {
    ...typography.subtitle,
    color: colors.textPrimary,
  },
  quickStatsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
  },
  quickStat: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  quickStatText: {
    ...typography.caption,
    color: colors.textPrimary,
    fontWeight: "600",
  },
  expandedSection: {
    marginTop: spacing.lg,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginBottom: spacing.lg,
  },
});
