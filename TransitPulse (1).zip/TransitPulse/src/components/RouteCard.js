// src/components/RouteCard.js
import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing, typography, shadow } from "../constants/theme";
import { formatDuration, formatFare } from "../utils/formatters";

export default function RouteCard({ route, onPress }) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.numberBadge}>
        <Text style={styles.numberText}>{route.number}</Text>
      </View>

      <View style={styles.body}>
        <Text style={styles.title} numberOfLines={1}>
          {route.name}
        </Text>
        <View style={styles.originDestRow}>
          <Text style={styles.originDest} numberOfLines={1}>
            {route.origin}
          </Text>
          <Ionicons name="arrow-forward" size={12} color={colors.textTertiary} style={styles.arrowIcon} />
          <Text style={styles.originDest} numberOfLines={1}>
            {route.destination}
          </Text>
        </View>

        <View style={styles.metaRow}>
          <View style={styles.metaItem}>
            <Ionicons name="bus-outline" size={13} color={colors.textSecondary} />
            <Text style={styles.metaText}>{route.busCount} buses live</Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="time-outline" size={13} color={colors.textSecondary} />
            <Text style={styles.metaText}>{formatDuration(route.estimatedMinutes)}</Text>
          </View>
          <View style={styles.metaItem}>
            <Ionicons name="pricetag-outline" size={13} color={colors.textSecondary} />
            <Text style={styles.metaText}>{formatFare(route.fare)}</Text>
          </View>
        </View>
      </View>

      <Ionicons name="chevron-forward" size={20} color={colors.textTertiary} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    ...Platform.select({ ios: shadow.card, android: {} }),
  },
  numberBadge: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
    marginRight: spacing.md,
  },
  numberText: {
    ...typography.subtitle,
    color: colors.primary,
  },
  body: {
    flex: 1,
  },
  title: {
    ...typography.subtitle,
    color: colors.textPrimary,
    marginBottom: 3,
  },
  originDestRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.sm,
  },
  originDest: {
    ...typography.caption,
    color: colors.textSecondary,
    maxWidth: "42%",
  },
  arrowIcon: {
    marginHorizontal: 6,
  },
  metaRow: {
    flexDirection: "row",
    gap: spacing.md,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  metaText: {
    ...typography.micro,
    color: colors.textSecondary,
  },
});
