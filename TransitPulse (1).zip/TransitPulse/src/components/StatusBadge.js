// src/components/StatusBadge.js
import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { colors, radius, spacing, typography, STATUS_COLORS } from "../constants/theme";

export default function StatusBadge({ status, size = "md" }) {
  const palette = STATUS_COLORS[status] || STATUS_COLORS.Moving;
  const isSmall = size === "sm";

  return (
    <View
      style={[
        styles.badge,
        { backgroundColor: palette.bg },
        isSmall && styles.badgeSmall,
      ]}
    >
      {(status === "Moving" || status === "Arriving") && (
        <View style={[styles.dot, { backgroundColor: palette.fg }]} />
      )}
      <Text style={[styles.text, isSmall && styles.textSmall, { color: palette.fg }]}>
        {status}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: spacing.sm + 2,
    paddingVertical: 5,
    borderRadius: radius.pill,
    alignSelf: "flex-start",
  },
  badgeSmall: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
  },
  text: {
    ...typography.caption,
  },
  textSmall: {
    ...typography.micro,
  },
});
