// src/components/StopTimeline.js
import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, spacing, typography } from "../constants/theme";
import { formatDuration } from "../utils/formatters";

/**
 * Vertical stop-by-stop journey view. `currentStopIndex` (optional) marks
 * where a specific tracked bus currently is, so stops render as
 * passed / current / upcoming.
 */
export default function StopTimeline({ stops, currentStopIndex = -1, etasFromNow = [] }) {
  return (
    <View>
      {stops.map((stop, index) => {
        const isPassed = currentStopIndex >= 0 && index < currentStopIndex;
        const isCurrent = index === currentStopIndex;
        const isLast = index === stops.length - 1;

        return (
          <View key={stop.id} style={styles.row}>
            <View style={styles.markerColumn}>
              <View
                style={[
                  styles.dot,
                  isCurrent && styles.dotCurrent,
                  isPassed && styles.dotPassed,
                ]}
              >
                {isCurrent && <View style={styles.dotPulse} />}
              </View>
              {!isLast && (
                <View style={[styles.line, isPassed && styles.linePassed]} />
              )}
            </View>

            <View style={[styles.content, !isLast && styles.contentSpacing]}>
              <View style={styles.textRow}>
                <Text
                  style={[
                    styles.stopName,
                    isCurrent && styles.stopNameCurrent,
                    isPassed && styles.stopNamePassed,
                  ]}
                  numberOfLines={1}
                >
                  {index === 0 ? "Start · " : isLast ? "Destination · " : ""}
                  {stop.name}
                </Text>
                {isCurrent && (
                  <Ionicons name="bus" size={14} color={colors.primary} style={{ marginLeft: 6 }} />
                )}
              </View>
              {etasFromNow[index] != null && !isPassed && (
                <Text style={styles.etaText}>
                  {isCurrent ? "Currently here" : `Arrives in ${formatDuration(etasFromNow[index])}`}
                </Text>
              )}
            </View>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
  },
  markerColumn: {
    alignItems: "center",
    width: 24,
  },
  dot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    borderWidth: 2,
    borderColor: colors.borderStrong,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
  },
  dotCurrent: {
    borderColor: colors.primary,
    backgroundColor: colors.primary,
  },
  dotPassed: {
    borderColor: colors.success,
    backgroundColor: colors.success,
  },
  dotPulse: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: colors.surface,
  },
  line: {
    width: 2,
    flex: 1,
    backgroundColor: colors.border,
    marginTop: 2,
  },
  linePassed: {
    backgroundColor: colors.success,
  },
  content: {
    flex: 1,
    paddingLeft: spacing.md,
    paddingBottom: spacing.lg,
  },
  contentSpacing: {
    minHeight: 44,
  },
  textRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  stopName: {
    ...typography.bodyStrong,
    color: colors.textPrimary,
  },
  stopNameCurrent: {
    color: colors.primary,
  },
  stopNamePassed: {
    color: colors.textTertiary,
    fontWeight: "500",
  },
  etaText: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: 2,
  },
});
