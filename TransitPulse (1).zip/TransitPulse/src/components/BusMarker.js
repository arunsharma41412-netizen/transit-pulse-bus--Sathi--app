// src/components/BusMarker.js
import React from "react";
import { View, StyleSheet } from "react-native";
import { Marker } from "react-native-maps";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "../constants/theme";
import { STATUS_COLORS } from "../constants/theme";

/**
 * A rotating bus glyph on the map. `selected` renders a larger, highlighted
 * version so a passenger can tell which bus they're currently tracking
 * when several buses on the same route are visible at once.
 */
export default function BusMarker({ latitude, longitude, bearing = 0, status, selected = false }) {
  const palette = STATUS_COLORS[status] || STATUS_COLORS.Moving;

  return (
    <Marker
      coordinate={{ latitude, longitude }}
      anchor={{ x: 0.5, y: 0.5 }}
      rotation={0}
      tracksViewChanges={false}
    >
      <View style={[styles.wrapper, selected && styles.wrapperSelected]}>
        <View
          style={[
            styles.pin,
            { backgroundColor: selected ? colors.primary : palette.fg },
            selected && styles.pinSelected,
          ]}
        >
          <Ionicons
            name="bus"
            size={selected ? 16 : 12}
            color="#FFFFFF"
            style={{ transform: [{ rotate: `${bearing}deg` }] }}
          />
        </View>
      </View>
    </Marker>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignItems: "center",
    justifyContent: "center",
  },
  wrapperSelected: {
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  pin: {
    width: 26,
    height: 26,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#FFFFFF",
  },
  pinSelected: {
    width: 34,
    height: 34,
    borderRadius: 17,
    borderWidth: 3,
  },
});
