// src/components/ETADisplay.js
import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet } from "react-native";
import { colors, spacing, typography } from "../constants/theme";
import { formatDuration, timeAgo } from "../utils/formatters";

/**
 * Shows the ETA to the next stop, plus a self-refreshing "Updated X sec
 * ago" line. The "ago" text ticks forward every second on its own so the
 * UI visibly communicates liveness even between GPS updates.
 */
export default function ETADisplay({ etaMinutes, lastUpdated, size = "md" }) {
  const [, forceTick] = useState(0);

  useEffect(() => {
    const id = setInterval(() => forceTick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const isLarge = size === "lg";

  return (
    <View>
      <Text style={[styles.eta, isLarge && styles.etaLarge]}>{formatDuration(etaMinutes)}</Text>
      <Text style={styles.updated}>Updated {timeAgo(lastUpdated)}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  eta: {
    ...typography.h3,
    color: colors.primary,
  },
  etaLarge: {
    fontSize: 26,
    fontWeight: "800",
    letterSpacing: -0.4,
  },
  updated: {
    ...typography.micro,
    color: colors.textTertiary,
    marginTop: 2,
  },
});
