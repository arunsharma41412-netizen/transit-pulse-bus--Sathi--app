// src/components/SeatAvailability.js
import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing, typography } from "../constants/theme";

function levelFor(ratio) {
  if (ratio > 0.5) return { color: colors.success, label: "Plenty of seats" };
  if (ratio > 0.2) return { color: colors.warning, label: "Filling up" };
  return { color: colors.danger, label: "Nearly full" };
}

export default function SeatAvailability({ available, total, compact = false }) {
  const ratio = total > 0 ? available / total : 0;
  const { color, label } = levelFor(ratio);

  if (compact) {
    return (
      <View style={styles.compactRow}>
        <Ionicons name="people-outline" size={14} color={color} />
        <Text style={[styles.compactText, { color }]}>
          {available} seats left
        </Text>
      </View>
    );
  }

  return (
    <View>
      <View style={styles.headerRow}>
        <Text style={styles.title}>Seat Availability</Text>
        <Text style={[styles.badgeText, { color }]}>{label}</Text>
      </View>
      <View style={styles.track}>
        <View style={[styles.fill, { width: `${Math.max(ratio * 100, 3)}%`, backgroundColor: color }]} />
      </View>
      <View style={styles.statsRow}>
        <Text style={styles.statText}>
          <Text style={styles.statNumber}>{available}</Text> available
        </Text>
        <Text style={styles.statText}>
          <Text style={styles.statNumber}>{total - available}</Text> occupied
        </Text>
        <Text style={styles.statText}>
          <Text style={styles.statNumber}>{total}</Text> total
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: spacing.sm,
  },
  title: {
    ...typography.subtitle,
    color: colors.textPrimary,
  },
  badgeText: {
    ...typography.caption,
  },
  track: {
    height: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.surfaceAlt,
    overflow: "hidden",
  },
  fill: {
    height: "100%",
    borderRadius: radius.pill,
  },
  statsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: spacing.sm,
  },
  statText: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  statNumber: {
    color: colors.textPrimary,
    fontWeight: "700",
  },
  compactRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  compactText: {
    ...typography.caption,
    marginLeft: 4,
  },
});
