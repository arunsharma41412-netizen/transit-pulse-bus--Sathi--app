// src/components/BusCard.js
import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing, typography, shadow } from "../constants/theme";
import StatusBadge from "./StatusBadge";
import { formatDuration, formatSpeed, timeAgo, formatFare } from "../utils/formatters";

export default function BusCard({ bus, onPress, onTrackPress }) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.85}>
      <View style={styles.headerRow}>
        <View style={styles.titleGroup}>
          <Ionicons name="bus" size={18} color={colors.primary} />
          <Text style={styles.busNumber}>BUS {bus.number.split(" ").pop()}</Text>
        </View>
        <StatusBadge status={bus.status} size="sm" />
      </View>

      <Text style={styles.destination} numberOfLines={1}>
        To {bus.destination}
      </Text>

      <View style={styles.stopsRow}>
        <View style={styles.stopBlock}>
          <Text style={styles.stopLabel}>NEXT STOP</Text>
          <Text style={styles.stopValue} numberOfLines={1}>{bus.nextStop}</Text>
        </View>
        <View style={styles.stopBlock}>
          <Text style={styles.stopLabel}>ETA</Text>
          <Text style={[styles.stopValue, styles.etaValue]}>{formatDuration(bus.etaMinutes)}</Text>
        </View>
      </View>

      <View style={styles.divider} />

      <View style={styles.footerRow}>
        <View style={styles.footerItem}>
          <Ionicons name="speedometer-outline" size={14} color={colors.textSecondary} />
          <Text style={styles.footerText}>{formatSpeed(bus.speedKmh)}</Text>
        </View>
        <View style={styles.footerItem}>
          <Ionicons name="people-outline" size={14} color={colors.textSecondary} />
          <Text style={styles.footerText}>{bus.seatsAvailable} seats</Text>
        </View>
        <View style={styles.footerItem}>
          <Ionicons name="pricetag-outline" size={14} color={colors.textSecondary} />
          <Text style={styles.footerText}>{formatFare(bus.fare)}</Text>
        </View>
        <View style={styles.footerItem}>
          <Ionicons name="time-outline" size={14} color={colors.textSecondary} />
          <Text style={styles.footerText}>{timeAgo(bus.lastUpdated)}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.trackButton} onPress={onTrackPress} activeOpacity={0.85}>
        <Ionicons name="navigate" size={14} color={colors.textOnPrimary} />
        <Text style={styles.trackButtonText}>Track Live</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    ...Platform.select({ ios: shadow.card, android: {} }),
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: spacing.sm,
  },
  titleGroup: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  busNumber: {
    ...typography.subtitle,
    color: colors.textPrimary,
  },
  destination: {
    ...typography.body,
    color: colors.textSecondary,
    marginBottom: spacing.md,
  },
  stopsRow: {
    flexDirection: "row",
    gap: spacing.xl,
    marginBottom: spacing.md,
  },
  stopBlock: {
    flex: 1,
  },
  stopLabel: {
    ...typography.micro,
    color: colors.textTertiary,
    marginBottom: 2,
    letterSpacing: 0.4,
  },
  stopValue: {
    ...typography.bodyStrong,
    color: colors.textPrimary,
  },
  etaValue: {
    color: colors.primary,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginBottom: spacing.md,
  },
  footerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: spacing.lg,
  },
  footerItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  footerText: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  trackButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 11,
    gap: 6,
  },
  trackButtonText: {
    ...typography.bodyStrong,
    color: colors.textOnPrimary,
  },
});
