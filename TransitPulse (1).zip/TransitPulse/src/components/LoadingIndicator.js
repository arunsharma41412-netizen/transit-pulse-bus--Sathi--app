// src/components/LoadingIndicator.js
import React, { useEffect, useRef } from "react";
import { View, Text, StyleSheet, ActivityIndicator, Animated } from "react-native";
import { colors, radius, spacing, typography } from "../constants/theme";

export function LoadingScreen({ message = "Loading…" }) {
  return (
    <View style={styles.center}>
      <ActivityIndicator size="small" color={colors.primary} />
      <Text style={styles.message}>{message}</Text>
    </View>
  );
}

/** A shimmering placeholder block, used to build list skeletons. */
export function SkeletonBlock({ width, height, borderRadius = radius.sm, style }) {
  const opacity = useRef(new Animated.Value(0.35)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 0.85, duration: 650, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.35, duration: 650, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);

  return (
    <Animated.View
      style={[
        { width, height, borderRadius, backgroundColor: colors.surfaceAlt, opacity },
        style,
      ]}
    />
  );
}

export function BusCardSkeleton() {
  return (
    <View style={styles.cardSkeleton}>
      <View style={styles.rowBetween}>
        <SkeletonBlock width={100} height={16} />
        <SkeletonBlock width={60} height={18} borderRadius={radius.pill} />
      </View>
      <SkeletonBlock width={140} height={12} style={{ marginTop: spacing.md }} />
      <View style={[styles.rowBetween, { marginTop: spacing.lg }]}>
        <SkeletonBlock width={70} height={14} />
        <SkeletonBlock width={70} height={14} />
      </View>
      <SkeletonBlock width="100%" height={38} borderRadius={radius.md} style={{ marginTop: spacing.lg }} />
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: spacing.xxxl,
  },
  message: {
    ...typography.body,
    color: colors.textSecondary,
    marginTop: spacing.md,
  },
  cardSkeleton: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rowBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
});

export default { LoadingScreen, SkeletonBlock, BusCardSkeleton };
