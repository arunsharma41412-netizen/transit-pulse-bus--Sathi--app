// src/constants/theme.js
// Central design system for Transit Pulse.
// A restrained, professional light theme — a deep transit blue as the
// primary brand color, a warm amber as the sole accent (reserved for
// live/attention states), and neutral grays for structure.

export const colors = {
  // Brand
  primary: "#0B5FFF",
  primaryDark: "#0A47C2",
  primarySoft: "#EAF1FF",

  // Accent (used sparingly — live indicators, alerts)
  accent: "#F59B1D",
  accentSoft: "#FFF3E0",

  // Status
  success: "#1E9E5A",
  successSoft: "#E7F7EF",
  danger: "#D64545",
  dangerSoft: "#FDEAEA",
  warning: "#C77D00",
  warningSoft: "#FFF1DA",
  info: "#3E7BFA",
  infoSoft: "#EAF1FF",

  // Neutrals
  background: "#F6F7FB",
  surface: "#FFFFFF",
  surfaceAlt: "#F0F2F7",
  border: "#E4E7EE",
  borderStrong: "#D3D8E3",

  textPrimary: "#161B26",
  textSecondary: "#5B6472",
  textTertiary: "#8A93A3",
  textOnPrimary: "#FFFFFF",

  overlay: "rgba(16, 20, 30, 0.45)",
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 40,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  pill: 999,
};

export const typography = {
  h1: { fontSize: 28, fontWeight: "700", letterSpacing: -0.4 },
  h2: { fontSize: 22, fontWeight: "700", letterSpacing: -0.3 },
  h3: { fontSize: 18, fontWeight: "600" },
  subtitle: { fontSize: 15, fontWeight: "600" },
  body: { fontSize: 14, fontWeight: "400" },
  bodyStrong: { fontSize: 14, fontWeight: "600" },
  caption: { fontSize: 12, fontWeight: "500" },
  micro: { fontSize: 11, fontWeight: "500" },
};

export const shadow = {
  card: {
    shadowColor: "#101828",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  floating: {
    shadowColor: "#101828",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 6,
  },
};

// Status -> color mapping used across badges, markers, and cards
export const STATUS_COLORS = {
  Moving: { fg: colors.success, bg: colors.successSoft },
  "At Stop": { fg: colors.info, bg: colors.infoSoft },
  Arriving: { fg: colors.accent, bg: colors.accentSoft },
  Delayed: { fg: colors.danger, bg: colors.dangerSoft },
  Completed: { fg: colors.textTertiary, bg: colors.surfaceAlt },
};

export default { colors, spacing, radius, typography, shadow, STATUS_COLORS };
