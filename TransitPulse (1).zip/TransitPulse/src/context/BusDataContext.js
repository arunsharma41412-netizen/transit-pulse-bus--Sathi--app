// src/context/BusDataContext.js
//
// App-wide provider that:
//  1. Starts the GPS simulation engine exactly once for the app's lifetime.
//  2. Persists "recently searched" routes to AsyncStorage so they survive
//     app restarts (a small, realistic touch of persistence).
//  3. Exposes a rolling alerts feed from notificationService.

import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { startLiveTracking, stopLiveTracking } from "../services/mockBusService";
import { subscribeToAlerts } from "../services/notificationService";

const RECENTS_KEY = "@transitpulse/recent_searches";
const MAX_RECENTS = 6;

const BusDataContext = createContext(null);

export function BusDataProvider({ children }) {
  const [recentRoutes, setRecentRoutes] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    startLiveTracking();
    return () => stopLiveTracking();
  }, []);

  useEffect(() => {
    const unsub = subscribeToAlerts(setAlerts);
    return unsub;
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(RECENTS_KEY);
        if (raw) setRecentRoutes(JSON.parse(raw));
      } catch (e) {
        // Non-fatal — recents are a convenience, not critical state.
      } finally {
        setReady(true);
      }
    })();
  }, []);

  const addRecentRoute = useCallback((routeSummary) => {
    setRecentRoutes((prev) => {
      const withoutDup = prev.filter((r) => r.id !== routeSummary.id);
      const next = [routeSummary, ...withoutDup].slice(0, MAX_RECENTS);
      AsyncStorage.setItem(RECENTS_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  }, []);

  const clearRecentRoutes = useCallback(() => {
    setRecentRoutes([]);
    AsyncStorage.removeItem(RECENTS_KEY).catch(() => {});
  }, []);

  const value = useMemo(
    () => ({ recentRoutes, addRecentRoute, clearRecentRoutes, alerts, ready }),
    [recentRoutes, addRecentRoute, clearRecentRoutes, alerts, ready]
  );

  return <BusDataContext.Provider value={value}>{children}</BusDataContext.Provider>;
}

export function useBusData() {
  const ctx = useContext(BusDataContext);
  if (!ctx) throw new Error("useBusData must be used within a BusDataProvider");
  return ctx;
}

export default BusDataContext;
