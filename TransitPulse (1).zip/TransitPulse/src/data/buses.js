// src/data/buses.js
//
// Static identity data for the fleet. This is deliberately minimal — it
// describes WHICH buses exist and WHERE they start, not their live GPS
// state. Live state (position, speed, seats, status, timestamp) is owned
// entirely by services/gpsSimulationEngine.js, seeded from the values here.
//
// `startProgressRatio` (0..1) places a bus somewhere along its route's
// polyline when the app launches, so the fleet doesn't look like it just
// spawned at the depot. `direction` of 1 means travelling stop[0] -> last
// stop; -1 means the reverse working (last stop -> stop[0]).

export const BUSES = [
  // Route R-101 — Charbagh — Gomti Nagar Express
  { id: "B-2041", number: "UP32 BT 2041", routeId: "R-101", totalSeats: 42, startProgressRatio: 0.05, direction: 1 },
  { id: "B-2044", number: "UP32 BT 2044", routeId: "R-101", totalSeats: 42, startProgressRatio: 0.4, direction: 1 },
  { id: "B-2047", number: "UP32 BT 2047", routeId: "R-101", totalSeats: 42, startProgressRatio: 0.75, direction: -1 },

  // Route R-102 — Alambagh — Chinhat Cross City
  { id: "B-3102", number: "UP32 BT 3102", routeId: "R-102", totalSeats: 50, startProgressRatio: 0.1, direction: 1 },
  { id: "B-3108", number: "UP32 BT 3108", routeId: "R-102", totalSeats: 50, startProgressRatio: 0.5, direction: 1 },
  { id: "B-3115", number: "UP32 BT 3115", routeId: "R-102", totalSeats: 50, startProgressRatio: 0.85, direction: -1 },

  // Route R-103 — Airport — Hazratganj Shuttle
  { id: "B-4020", number: "UP32 BT 4020", routeId: "R-103", totalSeats: 36, startProgressRatio: 0.15, direction: 1 },
  { id: "B-4026", number: "UP32 BT 4026", routeId: "R-103", totalSeats: 36, startProgressRatio: 0.6, direction: -1 },
  { id: "B-4031", number: "UP32 BT 4031", routeId: "R-103", totalSeats: 36, startProgressRatio: 0.3, direction: 1 },

  // Route R-104 — Vikas Nagar — Alam Nagar Circular
  { id: "B-5011", number: "UP32 BT 5011", routeId: "R-104", totalSeats: 42, startProgressRatio: 0.2, direction: 1 },
  { id: "B-5017", number: "UP32 BT 5017", routeId: "R-104", totalSeats: 42, startProgressRatio: 0.55, direction: -1 },
  { id: "B-5023", number: "UP32 BT 5023", routeId: "R-104", totalSeats: 42, startProgressRatio: 0.9, direction: 1 },

  // Route R-105 — Chinhat — Rajajipuram Cross City
  { id: "B-6004", number: "UP32 BT 6004", routeId: "R-105", totalSeats: 50, startProgressRatio: 0.08, direction: 1 },
  { id: "B-6009", number: "UP32 BT 6009", routeId: "R-105", totalSeats: 50, startProgressRatio: 0.45, direction: 1 },
  { id: "B-6013", number: "UP32 BT 6013", routeId: "R-105", totalSeats: 50, startProgressRatio: 0.7, direction: -1 },
];

export function getBusesForRoute(routeId) {
  return BUSES.filter((b) => b.routeId === routeId);
}

export function getBusById(busId) {
  return BUSES.find((b) => b.id === busId) || null;
}

export default BUSES;
