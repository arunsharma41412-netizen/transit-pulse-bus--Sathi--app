// src/data/routes.js
//
// Synthetic route dataset. Coordinates are real Lucknow landmarks so the
// map looks and behaves like a genuine city bus network. This data is
// static "schedule" information — the GPS simulation engine is what makes
// buses move along these polylines in real time.

export const ROUTES = [
  {
    id: "R-101",
    name: "Charbagh — Gomti Nagar Express",
    number: "101",
    fare: 25,
    baseFare: 10,
    distanceKm: 14.2,
    estimatedMinutes: 42,
    stops: [
      { id: "S-101-1", name: "Charbagh Railway Station", latitude: 26.8302, longitude: 80.921 },
      { id: "S-101-2", name: "Aishbagh", latitude: 26.838, longitude: 80.908 },
      { id: "S-101-3", name: "Kaiserbagh", latitude: 26.853, longitude: 80.927 },
      { id: "S-101-4", name: "Hazratganj", latitude: 26.85, longitude: 80.943 },
      { id: "S-101-5", name: "Nishatganj", latitude: 26.86, longitude: 80.95 },
      { id: "S-101-6", name: "Mahanagar", latitude: 26.872, longitude: 80.943 },
      { id: "S-101-7", name: "Gomti Nagar", latitude: 26.862, longitude: 81.009 },
    ],
  },
  {
    id: "R-102",
    name: "Alambagh — Chinhat Cross City",
    number: "102",
    fare: 30,
    baseFare: 10,
    distanceKm: 20.5,
    estimatedMinutes: 58,
    stops: [
      { id: "S-102-1", name: "Alambagh", latitude: 26.81, longitude: 80.904 },
      { id: "S-102-2", name: "Charbagh Railway Station", latitude: 26.8302, longitude: 80.921 },
      { id: "S-102-3", name: "Aminabad", latitude: 26.858, longitude: 80.927 },
      { id: "S-102-4", name: "Chowk", latitude: 26.869, longitude: 80.904 },
      { id: "S-102-5", name: "Hazratganj", latitude: 26.85, longitude: 80.943 },
      { id: "S-102-6", name: "IndiraNagar", latitude: 26.878, longitude: 80.977 },
      { id: "S-102-7", name: "Polytechnic Chowk", latitude: 26.885, longitude: 80.98 },
      { id: "S-102-8", name: "Chinhat", latitude: 26.888, longitude: 81.027 },
    ],
  },
  {
    id: "R-103",
    name: "Airport — Hazratganj Shuttle",
    number: "103",
    fare: 28,
    baseFare: 15,
    distanceKm: 16.4,
    estimatedMinutes: 45,
    stops: [
      { id: "S-103-1", name: "Amausi Airport", latitude: 26.7606, longitude: 80.8893 },
      { id: "S-103-2", name: "Telibagh", latitude: 26.793, longitude: 80.944 },
      { id: "S-103-3", name: "Alambagh", latitude: 26.81, longitude: 80.904 },
      { id: "S-103-4", name: "Charbagh Railway Station", latitude: 26.8302, longitude: 80.921 },
      { id: "S-103-5", name: "Aishbagh", latitude: 26.838, longitude: 80.908 },
      { id: "S-103-6", name: "Hazratganj", latitude: 26.85, longitude: 80.943 },
    ],
  },
  {
    id: "R-104",
    name: "Vikas Nagar — Alam Nagar Circular",
    number: "104",
    fare: 27,
    baseFare: 10,
    distanceKm: 18.1,
    estimatedMinutes: 50,
    stops: [
      { id: "S-104-1", name: "Vikas Nagar", latitude: 26.905, longitude: 80.945 },
      { id: "S-104-2", name: "Mahanagar", latitude: 26.872, longitude: 80.943 },
      { id: "S-104-3", name: "Hazratganj", latitude: 26.85, longitude: 80.943 },
      { id: "S-104-4", name: "Kaiserbagh", latitude: 26.853, longitude: 80.927 },
      { id: "S-104-5", name: "Rajajipuram", latitude: 26.833, longitude: 80.885 },
      { id: "S-104-6", name: "Alam Nagar", latitude: 26.839, longitude: 80.885 },
    ],
  },
  {
    id: "R-105",
    name: "Chinhat — Rajajipuram Cross City",
    number: "105",
    fare: 32,
    baseFare: 15,
    distanceKm: 22.8,
    estimatedMinutes: 63,
    stops: [
      { id: "S-105-1", name: "Chinhat", latitude: 26.888, longitude: 81.027 },
      { id: "S-105-2", name: "Polytechnic Chowk", latitude: 26.885, longitude: 80.98 },
      { id: "S-105-3", name: "IndiraNagar", latitude: 26.878, longitude: 80.977 },
      { id: "S-105-4", name: "Mahanagar", latitude: 26.872, longitude: 80.943 },
      { id: "S-105-5", name: "Aminabad", latitude: 26.858, longitude: 80.927 },
      { id: "S-105-6", name: "Chowk", latitude: 26.869, longitude: 80.904 },
      { id: "S-105-7", name: "Rajajipuram", latitude: 26.833, longitude: 80.885 },
    ],
  },
];

export function getRouteById(routeId) {
  return ROUTES.find((r) => r.id === routeId) || null;
}

export default ROUTES;
