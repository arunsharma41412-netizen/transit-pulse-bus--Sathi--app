// src/screens/LiveTrackingScreen.js
import React, { useEffect, useRef, useState, useCallback } from "react";
import { View, StyleSheet, TouchableOpacity } from "react-native";
import MapView, { Polyline, Marker, PROVIDER_GOOGLE } from "react-native-maps";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { colors, radius, shadow } from "../constants/theme";
import BusMarker from "../components/BusMarker";
import MapPanel from "../components/MapPanel";
import EmptyState from "../components/EmptyState";
import { LoadingScreen } from "../components/LoadingIndicator";
import { getRouteDetail, subscribeToBus, subscribeToRoute } from "../services/mockBusService";
import { evaluateBus } from "../services/notificationService";

export default function LiveTrackingScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const mapRef = useRef(null);
  const busId = route?.params?.busId;

  const [routeInfo, setRouteInfo] = useState(null);
  const [bus, setBus] = useState(null);
  const [otherBuses, setOtherBuses] = useState([]);
  const [expanded, setExpanded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [hasCentered, setHasCentered] = useState(false);

  useEffect(() => {
    if (!busId) {
      setLoading(false);
    }
  }, [busId]);

  useEffect(() => {
    if (!busId) return;
    const unsubscribe = subscribeToBus(busId, (view) => {
      setBus(view);
      setLoading(false);
      evaluateBus(view);
      if (!routeInfo) {
        getRouteDetail(view.routeId).then(setRouteInfo);
      }
    });
    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [busId]);

  useEffect(() => {
    if (!bus?.routeId) return;
    const unsubscribe = subscribeToRoute(bus.routeId, (views) => {
      setOtherBuses(views.filter((v) => v.id !== busId));
    });
    return unsubscribe;
  }, [bus?.routeId, busId]);

  useEffect(() => {
    if (bus && mapRef.current && !hasCentered) {
      mapRef.current.animateToRegion(
        {
          latitude: bus.latitude,
          longitude: bus.longitude,
          latitudeDelta: 0.06,
          longitudeDelta: 0.06,
        },
        600
      );
      setHasCentered(true);
    }
  }, [bus, hasCentered]);

  const recenter = useCallback(() => {
    if (bus && mapRef.current) {
      mapRef.current.animateToRegion(
        {
          latitude: bus.latitude,
          longitude: bus.longitude,
          latitudeDelta: 0.035,
          longitudeDelta: 0.035,
        },
        450
      );
    }
  }, [bus]);

  if (!busId) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <EmptyState
          icon="location-outline"
          title="No bus selected"
          message="Search for a route and choose a bus to start live tracking."
          actionLabel="Find a route"
          onAction={() => navigation.navigate("RoutesTab")}
        />
      </View>
    );
  }

  if (loading || !bus) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <LoadingScreen message="Connecting to live GPS…" />
      </View>
    );
  }

  const polylineCoords = routeInfo
    ? routeInfo.stops.map((s) => ({ latitude: s.latitude, longitude: s.longitude }))
    : [];

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        provider={PROVIDER_GOOGLE}
        initialRegion={{
          latitude: bus.latitude,
          longitude: bus.longitude,
          latitudeDelta: 0.08,
          longitudeDelta: 0.08,
        }}
        showsUserLocation={false}
        showsMyLocationButton={false}
        showsCompass={false}
      >
        {polylineCoords.length > 0 && (
          <Polyline
            coordinates={polylineCoords}
            strokeColor={colors.primary}
            strokeWidth={4}
            lineDashPattern={[1]}
          />
        )}

        {routeInfo?.stops.map((stop, idx) => (
          <Marker
            key={stop.id}
            coordinate={{ latitude: stop.latitude, longitude: stop.longitude }}
            anchor={{ x: 0.5, y: 0.5 }}
            tracksViewChanges={false}
          >
            <View
              style={[
                styles.stopDot,
                (idx === 0 || idx === routeInfo.stops.length - 1) && styles.terminusDot,
              ]}
            />
          </Marker>
        ))}

        {otherBuses.map((ob) => (
          <BusMarker
            key={ob.id}
            latitude={ob.latitude}
            longitude={ob.longitude}
            bearing={ob.bearing}
            status={ob.status}
          />
        ))}

        <BusMarker latitude={bus.latitude} longitude={bus.longitude} bearing={bus.bearing} status={bus.status} selected />
      </MapView>

      <View style={[styles.topBar, { top: insets.top + 8 }]}>
        <TouchableOpacity style={styles.iconButton} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={20} color={colors.textPrimary} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconButton} onPress={recenter}>
          <Ionicons name="locate" size={20} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <MapPanel
        bus={bus}
        expanded={expanded}
        onExpand={() => setExpanded(true)}
        onCollapse={() => setExpanded(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  map: {
    flex: 1,
  },
  topBar: {
    position: "absolute",
    left: 16,
    right: 16,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: radius.pill,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...shadow.card,
  },
  stopDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.surface,
    borderWidth: 2,
    borderColor: colors.borderStrong,
  },
  terminusDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    borderColor: colors.primary,
    backgroundColor: colors.primary,
  },
});
