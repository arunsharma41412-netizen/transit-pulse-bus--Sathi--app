// src/screens/HomeScreen.js
import React, { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  RefreshControl,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { colors, radius, spacing, typography, shadow } from "../constants/theme";
import SearchBar from "../components/SearchBar";
import { getRoutes } from "../services/mockBusService";
import { useBusData } from "../context/BusDataContext";
import { formatFare, formatDuration } from "../utils/formatters";
import { SkeletonBlock } from "../components/LoadingIndicator";

export default function HomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { recentRoutes, alerts } = useBusData();
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    const data = await getRoutes();
    setRoutes(data);
    setLoading(false);
    setRefreshing(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const onRefresh = () => {
    setRefreshing(true);
    load();
  };

  const totalLiveBuses = routes.reduce((sum, r) => sum + r.busCount, 0);
  const latestAlert = alerts[0];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Transit Pulse</Text>
            <Text style={styles.subGreeting}>Where is my bus, right now?</Text>
          </View>
          <TouchableOpacity style={styles.liveBadge}>
            <View style={styles.liveDot} />
            <Text style={styles.liveBadgeText}>{loading ? "—" : totalLiveBuses} live</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={() => navigation.navigate("RouteSearch")} activeOpacity={0.9}>
          <View pointerEvents="none">
            <SearchBar value="" onChangeText={() => {}} placeholder="Search source, destination or bus no." />
          </View>
        </TouchableOpacity>

        {latestAlert && (
          <View style={styles.alertBanner}>
            <Ionicons name="notifications" size={16} color={colors.accent} />
            <Text style={styles.alertText} numberOfLines={1}>{latestAlert.message}</Text>
          </View>
        )}

        <View style={styles.quickActionsRow}>
          <QuickAction
            icon="location"
            label="Live Tracking"
            onPress={() => navigation.navigate("LiveTracking")}
          />
          <QuickAction
            icon="map"
            label="All Routes"
            onPress={() => navigation.navigate("RouteSearch")}
          />
          <QuickAction
            icon="time"
            label="Recent"
            onPress={() => navigation.navigate("RouteSearch", { showRecents: true })}
          />
        </View>

        <SectionHeader title="Recently Searched" visible={recentRoutes.length > 0} />
        {recentRoutes.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.recentsRow}>
            {recentRoutes.map((r) => (
              <TouchableOpacity
                key={r.id}
                style={styles.recentChip}
                onPress={() => navigation.navigate("AvailableBuses", { routeId: r.id, routeName: r.name })}
              >
                <Text style={styles.recentChipNumber}>{r.number}</Text>
                <Text style={styles.recentChipName} numberOfLines={1}>{r.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}

        <SectionHeader title="Popular Routes" />
        {loading ? (
          <View style={{ gap: spacing.md }}>
            <SkeletonBlock width="100%" height={78} borderRadius={radius.lg} />
            <SkeletonBlock width="100%" height={78} borderRadius={radius.lg} />
            <SkeletonBlock width="100%" height={78} borderRadius={radius.lg} />
          </View>
        ) : (
          routes.slice(0, 5).map((route) => (
            <TouchableOpacity
              key={route.id}
              style={styles.popularCard}
              onPress={() => navigation.navigate("AvailableBuses", { routeId: route.id, routeName: route.name })}
              activeOpacity={0.85}
            >
              <View style={styles.popularBadge}>
                <Text style={styles.popularBadgeText}>{route.number}</Text>
              </View>
              <View style={styles.popularBody}>
                <Text style={styles.popularTitle} numberOfLines={1}>{route.name}</Text>
                <Text style={styles.popularMeta}>
                  {route.busCount} buses · {formatDuration(route.estimatedMinutes)} · {formatFare(route.fare)}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
            </TouchableOpacity>
          ))
        )}

        <View style={{ height: spacing.xxl }} />
      </ScrollView>
    </View>
  );
}

function QuickAction({ icon, label, onPress }) {
  return (
    <TouchableOpacity style={styles.quickAction} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.quickActionIcon}>
        <Ionicons name={icon} size={20} color={colors.primary} />
      </View>
      <Text style={styles.quickActionLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

function SectionHeader({ title, visible = true }) {
  if (!visible) return null;
  return <Text style={styles.sectionHeader}>{title}</Text>;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: spacing.lg,
  },
  greeting: {
    ...typography.h1,
    color: colors.textPrimary,
  },
  subGreeting: {
    ...typography.body,
    color: colors.textSecondary,
    marginTop: 2,
  },
  liveBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.successSoft,
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.pill,
    marginTop: 4,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.success,
    marginRight: 6,
  },
  liveBadgeText: {
    ...typography.caption,
    color: colors.success,
  },
  alertBanner: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.accentSoft,
    borderRadius: radius.md,
    paddingVertical: spacing.sm + 2,
    paddingHorizontal: spacing.md,
    marginTop: spacing.md,
    gap: spacing.sm,
  },
  alertText: {
    ...typography.caption,
    color: colors.warning,
    flex: 1,
  },
  quickActionsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: spacing.xl,
    marginBottom: spacing.xl,
  },
  quickAction: {
    alignItems: "center",
    flex: 1,
  },
  quickActionIcon: {
    width: 52,
    height: 52,
    borderRadius: radius.lg,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: spacing.sm,
  },
  quickActionLabel: {
    ...typography.caption,
    color: colors.textPrimary,
  },
  sectionHeader: {
    ...typography.h3,
    color: colors.textPrimary,
    marginBottom: spacing.md,
    marginTop: spacing.xs,
  },
  recentsRow: {
    marginBottom: spacing.xl,
  },
  recentChip: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: spacing.sm + 2,
    paddingHorizontal: spacing.md,
    marginRight: spacing.sm,
    width: 140,
  },
  recentChipNumber: {
    ...typography.caption,
    color: colors.primary,
    marginBottom: 2,
  },
  recentChipName: {
    ...typography.caption,
    color: colors.textPrimary,
    fontWeight: "600",
  },
  popularCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    ...Platform.select({ ios: shadow.card, android: {} }),
  },
  popularBadge: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
    marginRight: spacing.md,
  },
  popularBadgeText: {
    ...typography.subtitle,
    color: colors.primary,
  },
  popularBody: {
    flex: 1,
  },
  popularTitle: {
    ...typography.subtitle,
    color: colors.textPrimary,
    marginBottom: 2,
  },
  popularMeta: {
    ...typography.caption,
    color: colors.textSecondary,
  },
});
