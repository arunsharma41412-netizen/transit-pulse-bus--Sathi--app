// src/screens/AvailableBusesScreen.js
import React, { useEffect, useState, useCallback, useLayoutEffect } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, spacing, typography, radius } from "../constants/theme";
import BusCard from "../components/BusCard";
import EmptyState from "../components/EmptyState";
import { BusCardSkeleton } from "../components/LoadingIndicator";
import { subscribeToRoute, getRouteDetail } from "../services/mockBusService";
import { evaluateBus } from "../services/notificationService";

export default function AvailableBusesScreen({ route, navigation }) {
  const { routeId, routeName } = route.params;
  const [buses, setBuses] = useState([]);
  const [routeInfo, setRouteInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useLayoutEffect(() => {
    navigation.setOptions({ title: routeName || "Available Buses" });
  }, [navigation, routeName]);

  useEffect(() => {
    getRouteDetail(routeId).then(setRouteInfo);
  }, [routeId]);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = subscribeToRoute(routeId, (views) => {
      setBuses(views);
      setLoading(false);
      views.forEach(evaluateBus);
    });
    return unsubscribe;
  }, [routeId]);

  const trackBus = useCallback(
    (bus) => navigation.navigate("LiveTracking", { busId: bus.id, routeId }),
    [navigation, routeId]
  );

  const viewBusDetails = useCallback(
    (bus) => navigation.navigate("BusDetails", { busId: bus.id }),
    [navigation]
  );

  return (
    <View style={styles.container}>
      {routeInfo && (
        <TouchableOpacity
          style={styles.routeSummary}
          onPress={() => navigation.navigate("RouteDetails", { routeId })}
          activeOpacity={0.8}
        >
          <View style={styles.routeSummaryText}>
            <Text style={styles.routeSummaryTitle} numberOfLines={1}>
              {routeInfo.stops[0].name} → {routeInfo.stops[routeInfo.stops.length - 1].name}
            </Text>
            <Text style={styles.routeSummaryMeta}>
              {routeInfo.stops.length} stops · {routeInfo.distanceKm} km · ₹{routeInfo.fare}
            </Text>
          </View>
          <View style={styles.routeSummaryLink}>
            <Text style={styles.routeSummaryLinkText}>View route</Text>
            <Ionicons name="chevron-forward" size={14} color={colors.primary} />
          </View>
        </TouchableOpacity>
      )}

      {loading ? (
        <View style={styles.listContent}>
          <BusCardSkeleton />
          <BusCardSkeleton />
          <BusCardSkeleton />
        </View>
      ) : (
        <FlatList
          data={buses}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <BusCard
              bus={item}
              onPress={() => viewBusDetails(item)}
              onTrackPress={() => trackBus(item)}
            />
          )}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <EmptyState
              icon="bus-outline"
              title="No buses on this route right now"
              message="All buses on this route have completed their shift. Please check back later."
            />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  routeSummary: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: colors.primarySoft,
    marginHorizontal: spacing.lg,
    marginTop: spacing.lg,
    padding: spacing.lg,
    borderRadius: radius.lg,
  },
  routeSummaryText: {
    flex: 1,
    marginRight: spacing.md,
  },
  routeSummaryTitle: {
    ...typography.bodyStrong,
    color: colors.primaryDark,
  },
  routeSummaryMeta: {
    ...typography.caption,
    color: colors.primaryDark,
    marginTop: 2,
    opacity: 0.8,
  },
  routeSummaryLink: {
    flexDirection: "row",
    alignItems: "center",
    gap: 2,
  },
  routeSummaryLinkText: {
    ...typography.caption,
    color: colors.primary,
    fontWeight: "700",
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.xxl,
  },
});
