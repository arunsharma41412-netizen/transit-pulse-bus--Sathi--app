// src/screens/RouteDetailsScreen.js
import React, { useEffect, useState, useMemo } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import MapView, { Polyline, Marker, PROVIDER_GOOGLE } from "react-native-maps";
import { colors, radius, spacing, typography, shadow } from "../constants/theme";
import StopTimeline from "../components/StopTimeline";
import { LoadingScreen } from "../components/LoadingIndicator";
import { getRouteDetail, getBusesForRoute } from "../services/mockBusService";
import { formatDuration, formatFare } from "../utils/formatters";

export default function RouteDetailsScreen({ route, navigation }) {
  const { routeId } = route.params;
  const [routeInfo, setRouteInfo] = useState(null);
  const [busCount, setBusCount] = useState(null);

  useEffect(() => {
    getRouteDetail(routeId).then(setRouteInfo);
    getBusesForRoute(routeId).then((buses) => setBusCount(buses.length));
  }, [routeId]);

  const polylineCoords = useMemo(
    () => (routeInfo ? routeInfo.stops.map((s) => ({ latitude: s.latitude, longitude: s.longitude })) : []),
    [routeInfo]
  );

  if (!routeInfo) return <LoadingScreen message="Loading route…" />;

  const midStop = routeInfo.stops[Math.floor(routeInfo.stops.length / 2)];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.mapCard}>
        <MapView
          style={styles.map}
          provider={PROVIDER_GOOGLE}
          initialRegion={{
            latitude: midStop.latitude,
            longitude: midStop.longitude,
            latitudeDelta: 0.14,
            longitudeDelta: 0.14,
          }}
          scrollEnabled={false}
          zoomEnabled={false}
          pointerEvents="none"
        >
          <Polyline coordinates={polylineCoords} strokeColor={colors.primary} strokeWidth={4} />
          {routeInfo.stops.map((stop, idx) => (
            <Marker key={stop.id} coordinate={{ latitude: stop.latitude, longitude: stop.longitude }} anchor={{ x: 0.5, y: 0.5 }}>
              <View style={[styles.stopDot, (idx === 0 || idx === routeInfo.stops.length - 1) && styles.terminusDot]} />
            </Marker>
          ))}
        </MapView>
      </View>

      <View style={styles.summaryCard}>
        <View style={styles.summaryHeaderRow}>
          <View style={styles.numberBadge}>
            <Text style={styles.numberBadgeText}>{routeInfo.number}</Text>
          </View>
          <View style={{ flex: 1, marginLeft: spacing.md }}>
            <Text style={styles.summaryTitle} numberOfLines={2}>{routeInfo.name}</Text>
          </View>
        </View>

        <View style={styles.metricsRow}>
          <Metric icon="bus-outline" label="Live buses" value={busCount ?? "—"} />
          <Metric icon="time-outline" label="Journey time" value={formatDuration(routeInfo.estimatedMinutes)} />
          <Metric icon="map-outline" label="Distance" value={`${routeInfo.distanceKm} km`} />
          <Metric icon="pricetag-outline" label="Fare" value={formatFare(routeInfo.fare)} />
        </View>
      </View>

      <View style={styles.timelineCard}>
        <Text style={styles.timelineTitle}>Journey Stops</Text>
        <StopTimeline stops={routeInfo.stops} />
      </View>

      <TouchableOpacity
        style={styles.viewBusesButton}
        onPress={() => navigation.navigate("AvailableBuses", { routeId, routeName: routeInfo.name })}
        activeOpacity={0.85}
      >
        <Ionicons name="bus" size={17} color={colors.textOnPrimary} />
        <Text style={styles.viewBusesText}>View Buses on This Route</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function Metric({ icon, label, value }) {
  return (
    <View style={styles.metric}>
      <Ionicons name={icon} size={16} color={colors.primary} />
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xxxl,
  },
  mapCard: {
    height: 170,
    borderRadius: radius.lg,
    overflow: "hidden",
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  map: {
    flex: 1,
  },
  stopDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.surface,
    borderWidth: 2,
    borderColor: colors.borderStrong,
  },
  terminusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    borderColor: colors.primary,
    backgroundColor: colors.primary,
  },
  summaryCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    ...Platform.select({ ios: shadow.card, android: {} }),
  },
  summaryHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: spacing.lg,
  },
  numberBadge: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },
  numberBadgeText: {
    ...typography.subtitle,
    color: colors.primary,
  },
  summaryTitle: {
    ...typography.h3,
    color: colors.textPrimary,
  },
  metricsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  metric: {
    alignItems: "center",
    flex: 1,
    gap: 3,
  },
  metricValue: {
    ...typography.bodyStrong,
    color: colors.textPrimary,
    marginTop: 2,
  },
  metricLabel: {
    ...typography.micro,
    color: colors.textTertiary,
  },
  timelineCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    ...Platform.select({ ios: shadow.card, android: {} }),
  },
  timelineTitle: {
    ...typography.subtitle,
    color: colors.textPrimary,
    marginBottom: spacing.lg,
  },
  viewBusesButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: spacing.md + 2,
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  viewBusesText: {
    ...typography.bodyStrong,
    color: colors.textOnPrimary,
    fontSize: 15,
  },
});
