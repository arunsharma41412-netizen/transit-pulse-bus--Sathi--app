// src/screens/SettingsScreen.js
import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { colors, radius, spacing, typography, shadow } from "../constants/theme";
import EmptyState from "../components/EmptyState";
import { useBusData } from "../context/BusDataContext";
import { timeAgo } from "../utils/formatters";

const ALERT_ICONS = {
  info: { name: "information-circle", color: colors.info },
  warning: { name: "alert-circle", color: colors.warning },
};

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const { alerts, clearRecentRoutes } = useBusData();

  return (
    <ScrollView style={[styles.container, { paddingTop: insets.top }]} contentContainerStyle={styles.content}>
      <View style={styles.profileHeader}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={28} color={colors.primary} />
        </View>
        <View>
          <Text style={styles.name}>Passenger</Text>
          <Text style={styles.subtext}>Lucknow City Transit</Text>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Alerts</Text>
      <View style={styles.card}>
        {alerts.length === 0 ? (
          <EmptyState
            icon="notifications-outline"
            title="No alerts yet"
            message="You'll see arrival and delay alerts here as buses you're tracking approach your stop."
          />
        ) : (
          alerts.slice(0, 15).map((a, idx) => {
            const meta = ALERT_ICONS[a.type] || ALERT_ICONS.info;
            return (
              <View key={a.id} style={[styles.alertRow, idx !== alerts.length - 1 && styles.alertRowBorder]}>
                <Ionicons name={meta.name} size={18} color={meta.color} />
                <View style={{ flex: 1, marginLeft: spacing.md }}>
                  <Text style={styles.alertMessage}>{a.message}</Text>
                  <Text style={styles.alertTime}>{timeAgo(a.timestamp)}</Text>
                </View>
              </View>
            );
          })
        )}
      </View>

      <Text style={styles.sectionTitle}>Preferences</Text>
      <View style={styles.card}>
        <SettingRow icon="notifications-outline" label="Notification alerts" trailing="On" />
        <SettingRow icon="moon-outline" label="Appearance" trailing="Light" />
        <SettingRow icon="trash-outline" label="Clear recent searches" onPress={clearRecentRoutes} last />
      </View>

      <View style={styles.card}>
        <SettingRow icon="information-circle-outline" label="About Transit Pulse" trailing="v1.0.0" last />
      </View>

      <Text style={styles.disclaimer}>
        Transit Pulse uses simulated GPS data for demonstration purposes. Bus positions, speeds and
        seat counts are synthetic and do not reflect real vehicles.
      </Text>
    </ScrollView>
  );
}

function SettingRow({ icon, label, trailing, onPress, last = false }) {
  return (
    <TouchableOpacity
      style={[styles.settingRow, !last && styles.alertRowBorder]}
      onPress={onPress}
      disabled={!onPress}
      activeOpacity={0.7}
    >
      <Ionicons name={icon} size={18} color={colors.textSecondary} />
      <Text style={styles.settingLabel}>{label}</Text>
      {trailing ? <Text style={styles.settingTrailing}>{trailing}</Text> : (
        <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xxxl,
  },
  profileHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
    marginBottom: spacing.xl,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.primarySoft,
    alignItems: "center",
    justifyContent: "center",
  },
  name: {
    ...typography.h3,
    color: colors.textPrimary,
  },
  subtext: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: 2,
  },
  sectionTitle: {
    ...typography.subtitle,
    color: colors.textPrimary,
    marginBottom: spacing.sm,
    marginTop: spacing.sm,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    marginBottom: spacing.xl,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
    ...Platform.select({ ios: shadow.card, android: {} }),
  },
  alertRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    padding: spacing.lg,
  },
  alertRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  alertMessage: {
    ...typography.body,
    color: colors.textPrimary,
  },
  alertTime: {
    ...typography.micro,
    color: colors.textTertiary,
    marginTop: 2,
  },
  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: spacing.lg,
    gap: spacing.md,
  },
  settingLabel: {
    ...typography.body,
    color: colors.textPrimary,
    flex: 1,
  },
  settingTrailing: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  disclaimer: {
    ...typography.micro,
    color: colors.textTertiary,
    textAlign: "center",
    lineHeight: 16,
    marginTop: spacing.sm,
  },
});
