// src/screens/BusDetailsScreen.js
import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, radius, spacing, typography, shadow } from "../constants/theme";
import StatusBadge from "../components/StatusBadge";
import InfoRow from "../components/InfoRow";
import SeatAvailability from "../components/SeatAvailability";
import ETADisplay from "../components/ETADisplay";
import { LoadingScreen } from "../components/LoadingIndicator";
import EmptyState from "../components/EmptyState";
import { subscribeToBus } from "../services/mockBusService";
import { formatDistance, formatFare, formatSpeed, clockTime } from "../utils/formatters";

export default function BusDetailsScreen({ route, navigation }) {
  const { busId } = route.params;
  const [bus, setBus] = useState(null);

  useEffect(() => {
    const unsubscribe = subscribeToBus(busId, setBus);
    return unsubscribe;
  }, [busId]);

  if (!bus) return <LoadingScreen message="Fetching bus details…" />;

  const remainingDistanceM = Math.max(
    (bus.distanceKm ? bus.distanceKm * 1000 : 0) - bus.distanceTravelledM,
    0
  );

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.headerCard}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.busNumber}>BUS {bus.number.split(" ").pop()}</Text>
            <Text style={styles.plate}>{bus.number}</Text>
          </View>
          <StatusBadge status={bus.status} />
        </View>

        <View style={styles.routeLine}>
          <Text style={styles.routeText} numberOfLines={1}>{bus.origin}</Text>
          <Ionicons name="arrow-forward" size={13} color={colors.textTertiary} style={{ marginHorizontal: 6 }} />
          <Text style={styles.routeText} numberOfLines={1}>{bus.destination}</Text>
        </View>
        <Text style={styles.routeName}>{bus.routeNumber} · {bus.routeName}</Text>

        <View style={styles.etaBlock}>
          <View>
            <Text style={styles.etaLabel}>NEXT STOP</Text>
            <Text style={styles.etaStopName}>{bus.nextStop}</Text>
          </View>
          <ETADisplay etaMinutes={bus.etaMinutes} lastUpdated={bus.lastUpdated} size="lg" />
        </View>
      </View>

      <View style={styles.card}>
        <SeatAvailability available={bus.seatsAvailable} total={bus.totalSeats} />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Live Journey Info</Text>
        <InfoRow icon="speedometer-outline" label="Current speed" value={formatSpeed(bus.speedKmh)} />
        <InfoRow icon="location-outline" label="Current stop" value={bus.currentStop} />
        <InfoRow icon="flag-outline" label="Next stop" value={bus.nextStop} />
        <InfoRow icon="trail-sign-outline" label="Distance travelled" value={formatDistance(bus.distanceTravelledM)} />
        <InfoRow icon="map-outline" label="Remaining distance" value={formatDistance(remainingDistanceM)} />
        <InfoRow
          icon="time-outline"
          label="Last GPS update"
          value={clockTime(bus.lastUpdated)}
          last
        />
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Fare & Seats</Text>
        <InfoRow icon="pricetag-outline" label="Base fare" value={formatFare(bus.baseFare)} />
        <InfoRow icon="cash-outline" label="Route fare" value={formatFare(bus.fare)} />
        <InfoRow icon="people-outline" label="Total seats" value={`${bus.totalSeats}`} last />
      </View>

      <TouchableOpacity
        style={styles.trackButton}
        onPress={() => navigation.navigate("LiveTracking", { busId: bus.id, routeId: bus.routeId })}
        activeOpacity={0.85}
      >
        <Ionicons name="navigate" size={17} color={colors.textOnPrimary} />
        <Text style={styles.trackButtonText}>Track Live Bus</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.lg,
    paddingBottom: spacing.xxxl,
  },
  headerCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    ...Platform.select({ ios: shadow.card, android: {} }),
  },
  headerTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: spacing.sm,
  },
  busNumber: {
    ...typography.h2,
    color: colors.textPrimary,
  },
  plate: {
    ...typography.caption,
    color: colors.textTertiary,
    marginTop: 2,
  },
  routeLine: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: spacing.md,
  },
  routeText: {
    ...typography.body,
    color: colors.textPrimary,
    maxWidth: "42%",
    fontWeight: "600",
  },
  routeName: {
    ...typography.caption,
    color: colors.textSecondary,
    marginTop: 4,
  },
  etaBlock: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginTop: spacing.lg,
    paddingTop: spacing.lg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  etaLabel: {
    ...typography.micro,
    color: colors.textTertiary,
    letterSpacing: 0.4,
    marginBottom: 2,
  },
  etaStopName: {
    ...typography.subtitle,
    color: colors.textPrimary,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    ...Platform.select({ ios: shadow.card, android: {} }),
  },
  cardTitle: {
    ...typography.subtitle,
    color: colors.textPrimary,
    marginBottom: spacing.xs,
  },
  trackButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: spacing.md + 2,
    gap: spacing.sm,
    marginTop: spacing.sm,
  },
  trackButtonText: {
    ...typography.bodyStrong,
    color: colors.textOnPrimary,
    fontSize: 15,
  },
});
