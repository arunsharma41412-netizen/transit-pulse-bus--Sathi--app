// src/screens/RouteSearchScreen.js
import React, { useState, useEffect, useCallback, useRef } from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { colors, spacing, typography, radius } from "../constants/theme";
import SearchBar from "../components/SearchBar";
import RouteCard from "../components/RouteCard";
import EmptyState from "../components/EmptyState";
import { LoadingScreen } from "../components/LoadingIndicator";
import { getRoutes, searchRoutes } from "../services/mockBusService";
import { useBusData } from "../context/BusDataContext";

const DEBOUNCE_MS = 300;

export default function RouteSearchScreen({ navigation, route }) {
  const { recentRoutes, addRecentRoute, clearRecentRoutes } = useBusData();
  const [query, setQuery] = useState("");
  const [allRoutes, setAllRoutes] = useState([]);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const debounceRef = useRef(null);

  useEffect(() => {
    getRoutes().then((data) => {
      setAllRoutes(data);
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!query.trim()) {
      setResults([]);
      setSearching(false);
      return;
    }
    setSearching(true);
    debounceRef.current = setTimeout(async () => {
      const data = await searchRoutes(query);
      setResults(data);
      setSearching(false);
    }, DEBOUNCE_MS);
    return () => clearTimeout(debounceRef.current);
  }, [query]);

  const openRoute = useCallback(
    (r) => {
      addRecentRoute({ id: r.id, name: r.name, number: r.number });
      navigation.navigate("AvailableBuses", { routeId: r.id, routeName: r.name });
    },
    [navigation, addRecentRoute]
  );

  const isSearchMode = query.trim().length > 0;
  const listData = isSearchMode ? results : allRoutes;

  if (loading) return <LoadingScreen message="Loading routes…" />;

  return (
    <View style={styles.container}>
      <View style={styles.searchWrap}>
        <SearchBar
          value={query}
          onChangeText={setQuery}
          placeholder="Route no., source, destination or bus no."
          autoFocus={route?.params?.autoFocus}
        />
      </View>

      {!isSearchMode && recentRoutes.length > 0 && (
        <View style={styles.recentsHeader}>
          <Text style={styles.recentsTitle}>Recent Searches</Text>
          <TouchableOpacity onPress={clearRecentRoutes}>
            <Text style={styles.clearText}>Clear</Text>
          </TouchableOpacity>
        </View>
      )}

      {!isSearchMode && recentRoutes.length > 0 && (
        <View style={styles.recentChipsWrap}>
          {recentRoutes.map((r) => (
            <TouchableOpacity
              key={r.id}
              style={styles.recentChip}
              onPress={() => openRoute(r)}
            >
              <Ionicons name="time-outline" size={13} color={colors.textSecondary} />
              <Text style={styles.recentChipText} numberOfLines={1}>{r.number} · {r.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <FlatList
        data={listData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <RouteCard route={item} onPress={() => openRoute(item)} />}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          isSearchMode ? (
            <Text style={styles.resultsLabel}>
              {searching ? "Searching…" : `${results.length} result${results.length === 1 ? "" : "s"}`}
            </Text>
          ) : (
            <Text style={styles.resultsLabel}>All Routes</Text>
          )
        }
        ListEmptyComponent={
          !searching && isSearchMode ? (
            <EmptyState
              icon="alert-circle-outline"
              title="No route found"
              message={`We couldn't find a route, source, destination or bus number matching "${query}".`}
            />
          ) : null
        }
        keyboardShouldPersistTaps="handled"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  searchWrap: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.sm,
  },
  recentsHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    marginTop: spacing.sm,
  },
  recentsTitle: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  clearText: {
    ...typography.caption,
    color: colors.primary,
  },
  recentChipsWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.sm,
    gap: spacing.sm,
  },
  recentChip: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 7,
    gap: 6,
    maxWidth: "100%",
  },
  recentChipText: {
    ...typography.caption,
    color: colors.textPrimary,
  },
  listContent: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.xxl,
  },
  resultsLabel: {
    ...typography.caption,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
});
