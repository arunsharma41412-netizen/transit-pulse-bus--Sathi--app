// src/navigation/MainTabs.js
import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Ionicons } from "@expo/vector-icons";
import { colors } from "../constants/theme";

import HomeScreen from "../screens/HomeScreen";
import RouteSearchScreen from "../screens/RouteSearchScreen";
import AvailableBusesScreen from "../screens/AvailableBusesScreen";
import LiveTrackingScreen from "../screens/LiveTrackingScreen";
import BusDetailsScreen from "../screens/BusDetailsScreen";
import RouteDetailsScreen from "../screens/RouteDetailsScreen";
import SettingsScreen from "../screens/SettingsScreen";

const Tab = createBottomTabNavigator();
const HomeStack = createNativeStackNavigator();
const RoutesStack = createNativeStackNavigator();
const TrackingStack = createNativeStackNavigator();

const stackScreenOptions = {
  headerShown: true,
  headerStyle: { backgroundColor: colors.surface },
  headerTitleStyle: { color: colors.textPrimary, fontSize: 17, fontWeight: "700" },
  headerShadowVisible: false,
  contentStyle: { backgroundColor: colors.background },
};

function HomeStackNavigator() {
  return (
    <HomeStack.Navigator screenOptions={stackScreenOptions}>
      <HomeStack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
      <HomeStack.Screen name="RouteSearch" component={RouteSearchScreen} options={{ title: "Search Routes" }} />
      <HomeStack.Screen name="AvailableBuses" component={AvailableBusesScreen} options={{ title: "Available Buses" }} />
      <HomeStack.Screen name="RouteDetails" component={RouteDetailsScreen} options={{ title: "Route Details" }} />
      <HomeStack.Screen name="BusDetails" component={BusDetailsScreen} options={{ title: "Bus Details" }} />
      <HomeStack.Screen name="LiveTracking" component={LiveTrackingScreen} options={{ headerShown: false }} />
    </HomeStack.Navigator>
  );
}

function RoutesStackNavigator() {
  return (
    <RoutesStack.Navigator screenOptions={stackScreenOptions}>
      <RoutesStack.Screen name="RouteSearchRoot" component={RouteSearchScreen} options={{ title: "Routes" }} />
      <RoutesStack.Screen name="AvailableBuses" component={AvailableBusesScreen} options={{ title: "Available Buses" }} />
      <RoutesStack.Screen name="RouteDetails" component={RouteDetailsScreen} options={{ title: "Route Details" }} />
      <RoutesStack.Screen name="BusDetails" component={BusDetailsScreen} options={{ title: "Bus Details" }} />
      <RoutesStack.Screen name="LiveTracking" component={LiveTrackingScreen} options={{ headerShown: false }} />
    </RoutesStack.Navigator>
  );
}

function TrackingStackNavigator() {
  return (
    <TrackingStack.Navigator screenOptions={stackScreenOptions}>
      <TrackingStack.Screen
        name="LiveTracking"
        component={LiveTrackingScreen}
        options={{ headerShown: false }}
      />
      <TrackingStack.Screen name="BusDetails" component={BusDetailsScreen} options={{ title: "Bus Details" }} />
    </TrackingStack.Navigator>
  );
}

export default function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textTertiary,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          height: 60,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: "600" },
        tabBarIcon: ({ color, size }) => {
          const icons = {
            HomeTab: "home",
            RoutesTab: "map",
            TrackingTab: "location",
            SettingsTab: "person",
          };
          return <Ionicons name={icons[route.name]} size={size - 2} color={color} />;
        },
      })}
    >
      <Tab.Screen name="HomeTab" component={HomeStackNavigator} options={{ title: "Home" }} />
      <Tab.Screen name="RoutesTab" component={RoutesStackNavigator} options={{ title: "Routes" }} />
      <Tab.Screen name="TrackingTab" component={TrackingStackNavigator} options={{ title: "Live Tracking" }} />
      <Tab.Screen name="SettingsTab" component={SettingsScreen} options={{ title: "Profile" }} />
    </Tab.Navigator>
  );
}
