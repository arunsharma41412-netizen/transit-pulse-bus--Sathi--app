// src/navigation/RootNavigator.js
import React from "react";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import MainTabs from "./MainTabs";
import { colors } from "../constants/theme";

const navTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: colors.background,
    card: colors.surface,
    text: colors.textPrimary,
    border: colors.border,
    primary: colors.primary,
  },
};

export default function RootNavigator() {
  return (
    <NavigationContainer theme={navTheme}>
      <MainTabs />
    </NavigationContainer>
  );
}
