// src/utils/formatters.js

/** "3 sec ago" / "2 min ago" style relative time. */
export function timeAgo(timestamp) {
  const diffMs = Date.now() - timestamp;
  const diffSec = Math.max(0, Math.round(diffMs / 1000));
  if (diffSec < 5) return "just now";
  if (diffSec < 60) return `${diffSec} sec ago`;
  const diffMin = Math.round(diffSec / 60);
  if (diffMin < 60) return `${diffMin} min ago`;
  const diffHr = Math.round(diffMin / 60);
  return `${diffHr} hr ago`;
}

/** "10:42:15 PM" style clock time. */
export function clockTime(timestamp) {
  const d = new Date(timestamp);
  return d.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function formatDistance(meters) {
  if (meters < 1000) return `${Math.round(meters)} m`;
  return `${(meters / 1000).toFixed(1)} km`;
}

export function formatDuration(minutes) {
  if (minutes < 1) return "< 1 min";
  if (minutes < 60) return `${Math.round(minutes)} min`;
  const hrs = Math.floor(minutes / 60);
  const rem = Math.round(minutes % 60);
  return rem === 0 ? `${hrs} hr` : `${hrs} hr ${rem} min`;
}

export function formatFare(rupees) {
  return `\u20B9${rupees}`;
}

export function formatSpeed(kmh) {
  return `${Math.round(kmh)} km/h`;
}

export default {
  timeAgo,
  clockTime,
  formatDistance,
  formatDuration,
  formatFare,
  formatSpeed,
};
