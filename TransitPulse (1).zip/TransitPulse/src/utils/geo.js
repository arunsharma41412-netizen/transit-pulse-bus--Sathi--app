// src/utils/geo.js
// Small geometry helpers used by the GPS simulation engine to move a bus
// smoothly along a polyline of {latitude, longitude} points.

const EARTH_RADIUS_M = 6371000;

const toRad = (deg) => (deg * Math.PI) / 180;

/** Haversine distance between two coordinates, in meters. */
export function distanceMeters(a, b) {
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const lat1 = toRad(a.latitude);
  const lat2 = toRad(b.latitude);

  const sinDLat = Math.sin(dLat / 2);
  const sinDLon = Math.sin(dLon / 2);

  const h =
    sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLon * sinDLon;
  const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  return EARTH_RADIUS_M * c;
}

/** Total length of a polyline, in meters. */
export function polylineLength(points) {
  let total = 0;
  for (let i = 0; i < points.length - 1; i++) {
    total += distanceMeters(points[i], points[i + 1]);
  }
  return total;
}

/** Linear interpolation between two points at fraction t (0..1). */
export function lerpPoint(a, b, t) {
  return {
    latitude: a.latitude + (b.latitude - a.latitude) * t,
    longitude: a.longitude + (b.longitude - a.longitude) * t,
  };
}

/** Bearing in degrees from point a to point b (0 = north). */
export function bearingDegrees(a, b) {
  const lat1 = toRad(a.latitude);
  const lat2 = toRad(b.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const y = Math.sin(dLon) * Math.cos(lat2);
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
  const brng = (Math.atan2(y, x) * 180) / Math.PI;
  return (brng + 360) % 360;
}

/**
 * Given a polyline and a total distance travelled along it (in meters),
 * returns the interpolated {latitude, longitude}, the current segment
 * index, the bearing of travel, and the remaining distance to the end.
 */
export function pointAtDistance(points, distanceM) {
  if (points.length === 0) return null;
  if (distanceM <= 0) {
    return {
      position: points[0],
      segmentIndex: 0,
      bearing: bearingDegrees(points[0], points[1] || points[0]),
      remainingM: polylineLength(points),
    };
  }

  let travelled = 0;
  for (let i = 0; i < points.length - 1; i++) {
    const segLen = distanceMeters(points[i], points[i + 1]);
    if (travelled + segLen >= distanceM) {
      const t = segLen === 0 ? 0 : (distanceM - travelled) / segLen;
      const position = lerpPoint(points[i], points[i + 1], t);
      const totalLen = polylineLength(points);
      return {
        position,
        segmentIndex: i,
        bearing: bearingDegrees(points[i], points[i + 1]),
        remainingM: Math.max(totalLen - distanceM, 0),
      };
    }
    travelled += segLen;
  }

  // Past the end of the route
  const last = points[points.length - 1];
  const secondLast = points[points.length - 2] || last;
  return {
    position: last,
    segmentIndex: points.length - 2,
    bearing: bearingDegrees(secondLast, last),
    remainingM: 0,
  };
}

export default {
  distanceMeters,
  polylineLength,
  lerpPoint,
  bearingDegrees,
  pointAtDistance,
};
