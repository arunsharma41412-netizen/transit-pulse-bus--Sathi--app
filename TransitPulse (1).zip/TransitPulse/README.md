# Transit Pulse

A professional, production-styled bus tracking mobile app built with **React Native + Expo**. Transit Pulse lets a passenger search for a route, see every bus currently running on it, and track a chosen bus live on a map — its position, speed, ETA, seat availability, and status, all updating in real time.

> **This project uses fully synthetic, simulated GPS data.** There is no real bus fleet or live GPS hardware behind it. See [How the simulation works](#how-the-live-gps-simulation-works) below for details, and [Limitations](#limitations) for what that means in practice.

---

## Features

- **Route search** — by source, destination, route number, or bus number, with debounced search, recent searches (persisted with AsyncStorage), and a proper no-results state.
- **Available buses per route** — a live-updating list of every bus currently running a route, with ETA, next stop, speed, seats, and status.
- **Live map tracking** — a selected bus moves along its actual route polyline in real time, with stop markers, other buses on the same route shown as context, and a bottom info panel.
- **Bus details** — full journey info: distance travelled, distance remaining, current/next stop, last GPS update timestamp, fare, and seat counts.
- **Route details** — an ordered stop timeline with a route overview map.
- **Realistic seat simulation** — seats fill and empty as a simulated bus passes each stop.
- **Status engine** — buses transition between `Moving`, `At Stop`, `Arriving`, `Delayed`, and `Completed` based on their simulated position, not hardcoded flags.
- **Local alerts** — simple "Bus 204 is arriving" / "Bus 204 has been delayed" style notifications generated from live bus state.
- **Loading, empty, and error states** everywhere data is fetched — skeleton cards, empty search results, "no bus selected", etc.
- **Light, minimal, professional UI** — a single restrained color system (deep transit blue + a sparingly-used amber accent), no gradients, no glassmorphism, no decorative clutter.

## Screenshots

_Add screenshots or a screen recording here once you've run the app — e.g. `docs/home.png`, `docs/live-tracking.png`, `docs/bus-details.png`._

## Technology Stack

| Layer | Choice |
|---|---|
| Framework | React Native (Expo SDK 51), Expo Go compatible |
| Navigation | React Navigation (bottom tabs + native stacks) |
| Maps | `react-native-maps` |
| Persistence | `@react-native-async-storage/async-storage` (recent searches) |
| Icons | `@expo/vector-icons` (Ionicons) |
| State | React hooks + a small Context provider — no external state library needed |

## Architecture Overview

```
TransitPulse/
├── App.js                     Entry point — providers + navigation root
├── src/
│   ├── constants/theme.js     Design system: colors, spacing, type, shadows
│   ├── data/
│   │   ├── routes.js          Static route + stop dataset (5 routes)
│   │   └── buses.js           Static fleet identity dataset (15 buses)
│   ├── services/
│   │   ├── gpsSimulationEngine.js   The simulation "GPS receiver" — owns the tick loop
│   │   ├── mockBusService.js        API-shaped facade the UI actually talks to
│   │   └── notificationService.js   Local alert feed derived from live bus state
│   ├── utils/
│   │   ├── geo.js              Polyline interpolation, distance, bearing
│   │   └── formatters.js       Time-ago, clock time, fare, speed, distance formatting
│   ├── context/BusDataContext.js   Starts the simulation, holds recent searches + alerts
│   ├── navigation/
│   │   ├── RootNavigator.js    NavigationContainer
│   │   └── MainTabs.js         Bottom tabs, each wrapping its own stack
│   ├── components/             BusCard, RouteCard, StatusBadge, SeatAvailability,
│   │                           ETADisplay, BusMarker, StopTimeline, SearchBar,
│   │                           MapPanel, InfoRow, EmptyState, LoadingIndicator
│   └── screens/                Home, RouteSearch, AvailableBuses, LiveTracking,
│                               BusDetails, RouteDetails, Settings
```

**Data flow:** `gpsSimulationEngine` is the single source of live truth (one tick loop, shared across the app — like one GPS receiver). `mockBusService` reads from it and from the static route/bus datasets, and exposes plain async functions (`getRoutes`, `getBusesForRoute`, `subscribeToBus`, ...) that return/emit plain JSON-shaped objects. **Screens and components never import the simulation engine directly** — only `mockBusService`. That boundary is what makes the mock swappable (see below).

## How the live GPS simulation works

Real bus telemetry wasn't available for this project, so `gpsSimulationEngine.js` behaves the way a real GPS feed would, using synthetic data instead of hardware:

1. **Route geometry** — each route's stops (`src/data/routes.js`) are treated as a polyline. The engine precomputes the cumulative distance to each stop and the route's total length once at startup.
2. **Bus state** — each bus (`src/data/buses.js`) is seeded with a starting position expressed as *meters travelled along the polyline*, a direction, and a base speed.
3. **Tick loop** — every 3 seconds (`TICK_MS`), the engine advances every bus's progress by `speed × time`, using small randomized speed variation so buses don't move at a mechanically constant rate.
4. **Derived state** — from the new progress value, the engine recomputes: interpolated lat/lng, bearing, current stop, next stop, ETA to next stop, distance travelled, and a `status` (`Moving`, `At Stop`, `Arriving`, `Delayed`, `Completed`) — the status is *derived* from position/speed, never hardcoded.
5. **Seats** — when a bus's progress crosses a stop's distance marker, a portion of occupied seats "alight" and a portion of free seats "board", so seat counts drift realistically instead of jumping randomly.
6. **Termini & reversal** — when a bus reaches the end of its route, it dwells briefly (status `Completed`), then reverses direction and starts back — buses run continuous round trips rather than disappearing.
7. **Timestamps** — every tick stamps `lastUpdated = Date.now()`, which is what powers the "Updated 3 sec ago" / "Updated at 10:42:15 PM" displays.
8. **Pub/sub** — `mockBusService.subscribeToRoute()` / `subscribeToBus()` wrap the engine's subscription mechanism and re-shape its raw state into the view models screens consume.

The result is a bus that visibly, continuously moves along its real route shape — not a marker teleporting to random coordinates.

## Future Scalability — swapping in a real GPS API

Every screen and component talks only to **`src/services/mockBusService.js`**, never to the simulation engine or the static datasets directly. To connect a real backend later:

1. Create `src/services/realBusService.js` implementing the same exported functions as `mockBusService.js` (`getRoutes`, `getRouteDetail`, `searchRoutes`, `getBusesForRoute`, `getBusDetail`, `subscribeToRoute`, `subscribeToBus`, `startLiveTracking`, `stopLiveTracking`), backed by real HTTP calls and/or a WebSocket for live position pushes instead of the local tick loop.
2. Swap the import in the screens (or, more simply, re-export `realBusService` from `mockBusService.js`'s path, or introduce a single config flag that picks which implementation to import).
3. No screen, component, or navigation code needs to change, because they only ever consume the shape returned by these functions — not how that shape was produced.

## Installation

```bash
git clone <this-repo-url>
cd TransitPulse
npm install
```

## Running with Expo Go

```bash
npx expo start
```

Scan the QR code with the **Expo Go** app (iOS or Android) on your phone, or press `i` / `a` in the terminal to launch an iOS Simulator / Android Emulator.

> **Maps on Android** require a Google Maps API key. For a demo in Expo Go this is usually not required for basic map rendering, but if you see a blank map on a physical Android device, add a key under `expo.android.config.googleMaps.apiKey` in `app.json`. iOS uses Apple Maps by default with no extra setup.

## Project Structure

See [Architecture Overview](#architecture-overview) above for the full folder layout and responsibilities.

## Synthetic Dataset

- **5 routes** across Lucknow, with real landmark names and coordinates (Charbagh Railway Station, Hazratganj, Alambagh, Gomti Nagar, Chinhat, and more).
- **15 buses**, 3 per route, seeded at different points along their route and running in both directions.
- Each route carries stops, distance, estimated journey time, and fare; each bus carries live position, speed, ETA, seats, and status, all generated by the simulation engine described above.

## Future Improvements

- Real GPS/telemetry integration via `realBusService.js` (see [Future Scalability](#future-scalability--swapping-in-a-real-gps-api)).
- Push notifications (the current alert feed is in-app only, not a system push).
- User accounts, favorite routes/stops, and fare-card integration.
- Multi-city support (the dataset is currently Lucknow-only).
- Offline caching of route/stop data.

## Limitations

- All GPS positions, speeds, seat counts, and delays are **synthetic** — generated locally by `gpsSimulationEngine.js`, not received from real vehicles.
- There is no backend server; everything runs on-device.
- No payment or ticket booking is implemented (explicitly out of scope for this project).
- Maps require `react-native-maps`, which needs a native build for full functionality outside of Expo Go's supported feature set — basic map/marker/polyline rendering used here works in Expo Go.

## Credits

Built with React Native, Expo, React Navigation, and react-native-maps. Route and stop names reference real Lucknow locations for realism; all live data is simulated.

## License

MIT — feel free to fork and adapt for your own transit-tracking projects.
