// App.js
import React from "react";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import RootNavigator from "./src/navigation/RootNavigator";
import { BusDataProvider } from "./src/context/BusDataContext";

export default function App() {
  return (
    <SafeAreaProvider>
      <BusDataProvider>
        <StatusBar style="dark" />
        <RootNavigator />
      </BusDataProvider>
    </SafeAreaProvider>
  );
}
